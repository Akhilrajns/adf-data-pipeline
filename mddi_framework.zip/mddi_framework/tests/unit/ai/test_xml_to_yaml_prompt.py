# tests/unit/ai/test_xml_to_yaml_prompt.py
# ─────────────────────────────────────────────
# Unit tests for XML → YAML prompt builder
# ─────────────────────────────────────────────

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../.."))

from ai.prompts.xml_to_yaml_prompt import build_prompt


SAMPLE_XML = """<POWERMART>
  <MAPPING NAME="m_customer_load">
    <SOURCE NAME="src_customers" DBTYPE="Oracle"/>
    <TARGET NAME="tgt_customers" DBTYPE="SQL Server"/>
    <TRANSFORMATION TYPE="Expression" NAME="exp_clean"/>
  </MAPPING>
</POWERMART>"""

SAMPLE_METADATA = {
    "mapping_names": ["m_customer_load"],
    "workflow_names": [],
    "source_tables": ["src_customers"],
    "target_tables": ["tgt_customers"],
    "transformation_types": ["Expression"],
}


class TestXMLToYAMLPrompt:

    def test_prompt_contains_xml_content(self):
        prompt = build_prompt(SAMPLE_XML, SAMPLE_METADATA)
        assert "m_customer_load" in prompt

    def test_prompt_contains_metadata(self):
        prompt = build_prompt(SAMPLE_XML, SAMPLE_METADATA)
        assert "src_customers" in prompt
        assert "tgt_customers" in prompt

    def test_prompt_contains_system_instructions(self):
        prompt = build_prompt(SAMPLE_XML, SAMPLE_METADATA)
        assert "YAML" in prompt
        assert "pipeline" in prompt

    def test_prompt_is_string(self):
        prompt = build_prompt(SAMPLE_XML, SAMPLE_METADATA)
        assert isinstance(prompt, str)
        assert len(prompt) > 100
