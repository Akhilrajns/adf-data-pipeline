# tests/unit/connectors/test_mssql_connector.py
# ─────────────────────────────────────────────
# Unit tests for MSSQL Connector
# ─────────────────────────────────────────────

import pytest
from unittest.mock import MagicMock, patch
from connectors.databases.mssql_connector import MSSQLConnector

MOCK_CONFIG = {
    "name": "test_mssql",
    "host": "localhost",
    "port": 1433,
    "database": "testdb",
    "username": "sa",
    "password": "secret",
}


@pytest.fixture
def mock_spark():
    spark = MagicMock()
    mock_df = MagicMock()
    mock_df.count.return_value = 100
    spark.read.format.return_value.option.return_value.option.return_value \
        .option.return_value.option.return_value.option.return_value \
        .option.return_value.load.return_value = mock_df
    return spark, mock_df


@pytest.fixture
def connector(mock_spark):
    spark, _ = mock_spark
    return MSSQLConnector(config=MOCK_CONFIG, spark=spark)


class TestMSSQLConnector:

    def test_jdbc_url_built_correctly(self, connector):
        assert "localhost" in connector.jdbc_url
        assert "1433" in connector.jdbc_url
        assert "testdb" in connector.jdbc_url

    def test_read_table_calls_jdbc(self, connector, mock_spark):
        spark, mock_df = mock_spark
        result = connector.read(table="customers", schema="dbo")
        assert result is not None

    def test_read_with_query_wraps_as_subquery(self, connector, mock_spark):
        spark, _ = mock_spark
        with patch.object(connector.spark.read.format.return_value, 'option',
                          wraps=connector.spark.read.format.return_value.option):
            connector.read(query="SELECT * FROM dbo.customers")

    def test_test_connection_returns_true_on_success(self, connector, mock_spark):
        result = connector.test_connection()
        assert result is True

    def test_test_connection_returns_false_on_exception(self, connector):
        connector.spark.read.format.side_effect = Exception("Connection refused")
        result = connector.test_connection()
        assert result is False
