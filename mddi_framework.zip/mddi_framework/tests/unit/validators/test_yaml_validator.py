# tests/unit/validators/test_yaml_validator.py
# ─────────────────────────────────────────────
# Unit tests for YAML Validator
# ─────────────────────────────────────────────

import pytest
import tempfile
import yaml
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../.."))


VALID_PIPELINE = {
    "pipeline": {
        "name": "test_pipeline",
        "source": {"type": "mssql", "table": "customers"},
        "target": {"type": "delta", "table": "bronze_customers"},
    }
}

MISSING_SOURCE = {
    "pipeline": {
        "name": "test_pipeline",
        "target": {"type": "delta", "table": "bronze_customers"},
    }
}

INVALID_SOURCE_TYPE = {
    "pipeline": {
        "name": "test_pipeline",
        "source": {"type": "mongodb"},  # not in enum
        "target": {"type": "delta", "table": "t"},
    }
}


def write_yaml(data: dict) -> str:
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False)
    yaml.dump(data, tmp)
    tmp.close()
    return tmp.name


class TestYAMLValidator:

    def test_valid_pipeline_returns_no_errors(self):
        from validators.yaml_validator import YAMLValidator
        path = write_yaml(VALID_PIPELINE)
        errors = YAMLValidator().validate(path)
        assert errors == []

    def test_missing_source_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        path = write_yaml(MISSING_SOURCE)
        errors = YAMLValidator().validate(path)
        assert any("source" in e for e in errors)

    def test_invalid_source_type_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        path = write_yaml(INVALID_SOURCE_TYPE)
        errors = YAMLValidator().validate(path)
        assert len(errors) > 0

    def test_malformed_yaml_returns_parse_error(self):
        from validators.yaml_validator import YAMLValidator
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False)
        tmp.write("pipeline: {name: [invalid: yaml: :::}")
        tmp.close()
        errors = YAMLValidator().validate(tmp.name)
        assert len(errors) > 0
