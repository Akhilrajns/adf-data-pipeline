# tests/unit/modules/test_transformer.py
# ─────────────────────────────────────────────
# Unit tests for Transformer module
# ─────────────────────────────────────────────

import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../.."))


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("MDDI_Unit_Tests")
        .config("spark.sql.shuffle.partitions", "1")
        .getOrCreate()
    )


@pytest.fixture
def sample_df(spark):
    data = [
        ("C001", "John", "Doe", "john@example.com", 30),
        ("C002", "Jane", "Smith", "jane@example.com", 25),
        ("C003", None, "Brown", None, 22),
    ]
    return spark.createDataFrame(data, ["CUST_ID", "FIRST_NM", "LAST_NM", "EMAIL", "AGE"])


class TestTransformer:

    def test_rename_columns(self, spark, sample_df):
        from modules.transformation.transformer import Transformer
        t = Transformer()
        result = t.transform(sample_df, [{
            "type": "rename_columns",
            "mappings": {"CUST_ID": "customer_id", "EMAIL": "email_address"}
        }])
        assert "customer_id" in result.columns
        assert "email_address" in result.columns
        assert "CUST_ID" not in result.columns

    def test_filter_removes_null_rows(self, spark, sample_df):
        from modules.transformation.transformer import Transformer
        t = Transformer()
        result = t.transform(sample_df, [{
            "type": "filter",
            "condition": "CUST_ID IS NOT NULL AND FIRST_NM IS NOT NULL"
        }])
        assert result.count() == 2

    def test_expression_adds_column(self, spark, sample_df):
        from modules.transformation.transformer import Transformer
        t = Transformer()
        result = t.transform(sample_df, [{
            "type": "expression",
            "columns": {"full_name": "CONCAT(FIRST_NM, ' ', LAST_NM)"}
        }])
        assert "full_name" in result.columns

    def test_unknown_transform_raises_error(self, spark, sample_df):
        from modules.transformation.transformer import Transformer
        t = Transformer()
        with pytest.raises(ValueError, match="Unknown transformation type"):
            t.transform(sample_df, [{"type": "invalid_type"}])

    def test_empty_transformations_returns_original(self, spark, sample_df):
        from modules.transformation.transformer import Transformer
        t = Transformer()
        result = t.transform(sample_df, [])
        assert result.count() == sample_df.count()
