-- sql/pre_actions/customer_load_pre.sql
-- ─────────────────────────────────────────────
-- MDDI Pre-Action: Customer Load
-- Executes BEFORE extraction to prepare the environment
-- ─────────────────────────────────────────────

-- 1. Create staging table if not exists
CREATE TABLE IF NOT EXISTS bronze.customers_staging
USING DELTA
AS SELECT * FROM bronze.customers WHERE 1 = 0;

-- 2. Truncate staging area before new load
TRUNCATE TABLE bronze.customers_staging;

-- 3. Log pipeline start
INSERT INTO mddi.pipeline_audit (pipeline_name, event, event_ts)
VALUES ('customer_load', 'PRE_ACTION_COMPLETE', CURRENT_TIMESTAMP());
