-- sql/post_actions/customer_load_post.sql
-- ─────────────────────────────────────────────
-- MDDI Post-Action: Customer Load
-- Executes AFTER successful load to Delta Lake
-- ─────────────────────────────────────────────

-- 1. Optimize Delta table for query performance
OPTIMIZE main.bronze.customers ZORDER BY (customer_id);

-- 2. Vacuum old snapshots (retain 7 days)
VACUUM main.bronze.customers RETAIN 168 HOURS;

-- 3. Update pipeline watermark for next incremental run
MERGE INTO mddi.pipeline_watermarks AS target
USING (
  SELECT
    'customer_load'     AS pipeline_name,
    MAX(updated_at)     AS last_run_ts,
    CURRENT_TIMESTAMP() AS updated_at
  FROM main.bronze.customers
) AS source
ON target.pipeline_name = source.pipeline_name
WHEN MATCHED THEN UPDATE SET
  target.last_run_ts = source.last_run_ts,
  target.updated_at  = source.updated_at
WHEN NOT MATCHED THEN INSERT *;

-- 4. Refresh downstream silver view
REFRESH TABLE main.silver.customers_vw;

-- 5. Log pipeline completion
INSERT INTO mddi.pipeline_audit (pipeline_name, event, event_ts)
VALUES ('customer_load', 'POST_ACTION_COMPLETE', CURRENT_TIMESTAMP());
