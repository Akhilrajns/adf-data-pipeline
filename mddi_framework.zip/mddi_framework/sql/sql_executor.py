# sql/sql_executor.py
# ─────────────────────────────────────────────
# MDDI — SQL Executor
# Runs pre/post action SQL files against a Spark session
# ─────────────────────────────────────────────

import os
from typing import List
from pyspark.sql import SparkSession
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class SQLExecutor:
    """Executes ordered pre/post SQL files in a Spark session."""

    def __init__(self, spark: SparkSession, base_path: str = "."):
        self.spark = spark
        self.base_path = base_path

    def execute_files(self, sql_files: List[str], phase: str = "pre") -> None:
        """
        Execute a list of SQL files in order.

        Args:
            sql_files: List of file paths relative to base_path.
            phase: 'pre' or 'post' — used in log messages only.
        """
        if not sql_files:
            return

        logger.info(f"[SQL] Running {len(sql_files)} {phase}_action file(s)")

        for sql_file in sql_files:
            full_path = os.path.join(self.base_path, sql_file)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"[SQL] File not found: {full_path}")

            with open(full_path, "r") as f:
                sql_content = f.read()

            # Split on semicolon to support multi-statement files
            statements = [s.strip() for s in sql_content.split(";")
                          if s.strip() and not s.strip().startswith("--")]

            for stmt in statements:
                logger.info(f"[SQL] Executing from {sql_file}:\n{stmt[:120]}...")
                self.spark.sql(stmt)

        logger.info(f"[SQL] All {phase}_actions complete")
