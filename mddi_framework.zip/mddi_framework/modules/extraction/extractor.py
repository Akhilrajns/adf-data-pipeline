# modules/extraction/extractor.py
# ─────────────────────────────────────────────
# MDDI — Data Extraction Module
# Reads from any registered source connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.connector_factory import ConnectorFactory
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics

logger = MDDILogger.get_logger(__name__)


class Extractor:
    """
    Handles data extraction from any configured source.
    Supports full loads, incremental loads (watermark), and query overrides.
    """

    def __init__(self, spark: SparkSession, metrics: PipelineMetrics):
        self.spark = spark
        self.metrics = metrics

    def extract(self, source_config: Dict[str, Any],
                connection_config: Dict[str, Any],
                last_run_ts: str = None) -> DataFrame:
        """
        Extract data from the configured source.

        Args:
            source_config: The `source` block from the pipeline YAML.
            connection_config: The resolved connection credentials.
            last_run_ts: Watermark timestamp for incremental loads.

        Returns:
            Spark DataFrame of source data.
        """
        conn_type = source_config["type"]
        connector = ConnectorFactory.get_connector(conn_type, connection_config, self.spark)

        if not connector.test_connection():
            raise ConnectionError(f"Source connection failed for type: {conn_type}")

        query = source_config.get("query")
        if query and last_run_ts:
            query = query.replace("{last_run_ts}", last_run_ts)

        logger.info(f"[Extractor] Starting extraction | type={conn_type}")

        df = connector.read(
            table=source_config.get("table"),
            query=query,
            schema=source_config.get("schema"),
            path=source_config.get("path"),
        )

        self.metrics.source_row_count = df.count()
        logger.info(f"[Extractor] Extracted {self.metrics.source_row_count} rows")
        return df
