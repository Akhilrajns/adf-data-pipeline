# modules/transformation/transformer.py
# ─────────────────────────────────────────────
# MDDI — Transformation Engine
# Applies YAML-defined transformations to a DataFrame
# ─────────────────────────────────────────────

from typing import List, Dict, Any
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)

# ── Transformation Handlers ───────────────────────────────────────────────────

def apply_rename_columns(df: DataFrame, config: Dict) -> DataFrame:
    """Rename columns based on a mappings dict."""
    mappings = config.get("mappings", {})
    for old_name, new_name in mappings.items():
        if old_name in df.columns:
            df = df.withColumnRenamed(old_name, new_name)
            logger.info(f"[Transform] Renamed: {old_name} → {new_name}")
    return df


def apply_expression(df: DataFrame, config: Dict) -> DataFrame:
    """Add or overwrite columns using SQL expressions."""
    for col_name, expr in config.get("columns", {}).items():
        df = df.withColumn(col_name, F.expr(expr))
        logger.info(f"[Transform] Expression column: {col_name} = {expr}")
    return df


def apply_filter(df: DataFrame, config: Dict) -> DataFrame:
    """Filter rows using a SQL condition string."""
    condition = config.get("condition", "")
    if condition:
        before = df.count()
        df = df.filter(F.expr(condition))
        after = df.count()
        logger.info(f"[Transform] Filter: '{condition}' | {before} → {after} rows")
    return df


def apply_derive(df: DataFrame, config: Dict) -> DataFrame:
    """Derive new columns via SQL expressions (alias for expression)."""
    return apply_expression(df, config)


def apply_drop_columns(df: DataFrame, config: Dict) -> DataFrame:
    """Drop a list of columns from the DataFrame."""
    cols = config.get("columns", [])
    df = df.drop(*[c for c in cols if c in df.columns])
    logger.info(f"[Transform] Dropped columns: {cols}")
    return df


def apply_cast_columns(df: DataFrame, config: Dict) -> DataFrame:
    """Cast columns to specified data types."""
    for col_name, dtype in config.get("columns", {}).items():
        if col_name in df.columns:
            df = df.withColumn(col_name, F.col(col_name).cast(dtype))
            logger.info(f"[Transform] Cast: {col_name} → {dtype}")
    return df


def apply_dedup(df: DataFrame, config: Dict) -> DataFrame:
    """Deduplicate rows, optionally on specific columns."""
    subset = config.get("columns")
    before = df.count()
    df = df.dropDuplicates(subset) if subset else df.dropDuplicates()
    logger.info(f"[Transform] Dedup | {before} → {df.count()} rows")
    return df


# ── Transformation Dispatcher ─────────────────────────────────────────────────

TRANSFORM_HANDLERS = {
    "rename_columns": apply_rename_columns,
    "expression": apply_expression,
    "filter": apply_filter,
    "derive": apply_derive,
    "drop_columns": apply_drop_columns,
    "cast_columns": apply_cast_columns,
    "dedup": apply_dedup,
}


class Transformer:
    """Applies a sequence of transformations defined in the pipeline YAML."""

    def transform(self, df: DataFrame,
                  transformations: List[Dict[str, Any]]) -> DataFrame:
        if not transformations:
            logger.info("[Transformer] No transformations defined.")
            return df

        for step in transformations:
            t_type = step.get("type")
            handler = TRANSFORM_HANDLERS.get(t_type)
            if not handler:
                raise ValueError(
                    f"Unknown transformation type: '{t_type}'. "
                    f"Available: {list(TRANSFORM_HANDLERS.keys())}"
                )
            logger.info(f"[Transformer] Applying: {t_type}")
            df = handler(df, step)

        return df
