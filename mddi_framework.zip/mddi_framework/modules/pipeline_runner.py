# modules/pipeline_runner.py
# ─────────────────────────────────────────────
# MDDI — Pipeline Runner (Orchestrator)
# Wires together all modules to execute a full pipeline
# ─────────────────────────────────────────────
#
# Usage:
#   python -m modules.pipeline_runner --config config/pipelines/sample_pipeline.yml
#
# ─────────────────────────────────────────────

import argparse
from monitoring.logger import MDDILogger, MDDILogger
from monitoring.metrics import PipelineMetrics
from modules.extraction.extractor import Extractor
from modules.transformation.transformer import Transformer
from modules.loading.loader import Loader
from modules.quality.dq_engine import DQEngine
from delta.delta_writer import DeltaWriter
from sql.sql_executor import SQLExecutor
from validators.yaml_validator import YAMLValidator
from utils.config_loader import ConfigLoader
from utils.spark_session import get_spark
from utils.run_id import generate_run_id

logger = MDDILogger.get_logger(__name__)


class PipelineRunner:

    def __init__(self, config_path: str, env_config_path: str = "config/global_config.yml"):
        self.config_loader = ConfigLoader(global_config_path=env_config_path)
        self.pipeline_config = self.config_loader.load_pipeline(config_path)
        self.spark = get_spark(app_name=self.pipeline_config.get("name", "MDDI"))
        self.run_id = generate_run_id(self.pipeline_config["name"])

    def run(self) -> PipelineMetrics:
        cfg = self.pipeline_config
        pipeline_name = cfg["name"]
        metrics = PipelineMetrics(pipeline_name=pipeline_name, run_id=self.run_id)

        logger.info(f"{'='*60}")
        logger.info(f"[Pipeline] START | {pipeline_name} | run_id={self.run_id}")
        logger.info(f"{'='*60}")

        try:
            # ── 0. Validate YAML ─────────────────────────────────────────────
            logger.info("[Pipeline] Step 0: Validating pipeline config")
            # (Validator was already run at startup — logged only)

            # ── 1. Pre-Actions ───────────────────────────────────────────────
            logger.info("[Pipeline] Step 1: Running pre-actions")
            sql_executor = SQLExecutor(self.spark)
            sql_executor.execute_files(cfg.get("pre_actions", []), phase="pre")

            # ── 2. Extract ───────────────────────────────────────────────────
            logger.info("[Pipeline] Step 2: Extracting source data")
            source_cfg = cfg["source"]
            conn_config = self.config_loader.get_connection(
                source_cfg.get("connection_ref", "")
            ) if source_cfg.get("connection_ref") else {}

            extractor = Extractor(self.spark, metrics)
            df = extractor.extract(source_cfg, conn_config)

            # ── 3. Transform ─────────────────────────────────────────────────
            logger.info("[Pipeline] Step 3: Applying transformations")
            transformer = Transformer()
            df = transformer.transform(df, cfg.get("transformations", []))

            # ── 4. Data Quality ──────────────────────────────────────────────
            logger.info("[Pipeline] Step 4: Running data quality checks")
            dq_config = cfg.get("data_quality", {})
            dq_engine = DQEngine(self.spark, metrics)
            df, quarantine_df = dq_engine.run(df, dq_config)

            # Save quarantine rows
            if quarantine_df and quarantine_df.count() > 0:
                delta_writer = DeltaWriter(self.spark)
                delta_writer.save_quarantine(quarantine_df, pipeline_name)

            # ── 5. Load ──────────────────────────────────────────────────────
            logger.info("[Pipeline] Step 5: Loading to target")
            target_cfg = cfg["target"]
            target_conn_config = self.config_loader.get_connection(
                target_cfg.get("connection_ref", "")
            ) if target_cfg.get("connection_ref") else {}

            loader = Loader(self.spark, metrics)
            loader.load(df, target_cfg, target_conn_config)

            # ── 6. Post-Actions ──────────────────────────────────────────────
            logger.info("[Pipeline] Step 6: Running post-actions")
            sql_executor.execute_files(cfg.get("post_actions", []), phase="post")

            # ── 7. Finalize Metrics ──────────────────────────────────────────
            metrics.complete(status="SUCCESS")
            MDDILogger.log_pipeline_event(
                self.spark, pipeline_name, "PIPELINE_COMPLETE", "SUCCESS",
                details=metrics.to_dict()
            )

        except Exception as e:
            logger.error(f"[Pipeline] FAILED: {e}", exc_info=True)
            metrics.complete(status="FAILED", error=str(e))
            MDDILogger.log_pipeline_event(
                self.spark, pipeline_name, "PIPELINE_FAILED", "FAILED",
                details={"error": str(e)}
            )
            raise

        finally:
            metrics.save_to_delta(self.spark)
            logger.info(f"[Pipeline] END | {pipeline_name} | "
                        f"Status={metrics.status} | Duration={metrics.duration_seconds}s")

        return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MDDI Pipeline Runner")
    parser.add_argument("--config", required=True, help="Path to pipeline YAML")
    args = parser.parse_args()

    runner = PipelineRunner(config_path=args.config)
    runner.run()
