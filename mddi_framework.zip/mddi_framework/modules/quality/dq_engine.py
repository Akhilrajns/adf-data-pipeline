# modules/quality/dq_engine.py
# ─────────────────────────────────────────────
# MDDI — Data Quality Engine
# Runs DQ checks defined in the pipeline YAML
# Supports: not_null, unique, regex, min_length,
#           min_value, max_value, allowed_values, custom_sql
# ─────────────────────────────────────────────

import re
from typing import List, Dict, Any, Tuple
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics

logger = MDDILogger.get_logger(__name__)


class DQEngine:
    """
    Validates a DataFrame against YAML-defined DQ rules.
    Returns a clean DataFrame and (if on_failure=quarantine) a quarantine DataFrame.
    """

    def __init__(self, spark: SparkSession, metrics: PipelineMetrics):
        self.spark = spark
        self.metrics = metrics

    def run(self, df: DataFrame, dq_config: Dict[str, Any]) -> Tuple[DataFrame, DataFrame]:
        """
        Execute all DQ rules in the pipeline config.

        Returns:
            (clean_df, quarantine_df)
        """
        rules = dq_config.get("rules", [])
        on_failure = dq_config.get("on_failure", "warn")  # quarantine | fail | warn

        if not rules:
            logger.info("[DQ] No quality rules defined.")
            return df, self.spark.createDataFrame([], df.schema)

        # Build a composite failure flag column
        fail_conditions = []
        for rule in rules:
            col = rule["column"]
            for check in rule.get("checks", []):
                cond = self._build_condition(col, check, rule)
                if cond is not None:
                    fail_conditions.append(cond)

        if not fail_conditions:
            return df, self.spark.createDataFrame([], df.schema)

        # A row fails if ANY check fails
        fail_expr = fail_conditions[0]
        for cond in fail_conditions[1:]:
            fail_expr = fail_expr | cond

        df = df.withColumn("_dq_failed", fail_expr)
        clean_df = df.filter(~F.col("_dq_failed")).drop("_dq_failed")
        quarantine_df = df.filter(F.col("_dq_failed")).drop("_dq_failed")

        pass_count = clean_df.count()
        fail_count = quarantine_df.count()

        self.metrics.dq_pass_count = pass_count
        self.metrics.dq_fail_count = fail_count
        self.metrics.quarantine_row_count = fail_count

        logger.info(f"[DQ] Pass={pass_count} | Fail={fail_count} | on_failure={on_failure}")

        if on_failure == "fail" and fail_count > 0:
            raise ValueError(f"[DQ] {fail_count} rows failed quality checks. Aborting.")
        if on_failure == "warn" and fail_count > 0:
            logger.warning(f"[DQ] {fail_count} rows failed quality checks (warn mode).")

        return clean_df, quarantine_df

    def _build_condition(self, col: str, check: str, rule: Dict) -> F.Column:
        """Returns a Spark Column expression that is TRUE when a row FAILS the check."""
        if check == "not_null":
            return F.col(col).isNull()
        elif check == "unique":
            # Mark rows where the value appears more than once
            from pyspark.sql import Window
            window = Window.partitionBy(col)
            # This approach tags duplicate rows during DQ pass
            logger.info(f"[DQ] 'unique' check on '{col}' applied via count window")
            return None  # Handled separately if needed
        elif check == "regex":
            pattern = rule.get("regex_pattern", ".*")
            return ~F.col(col).rlike(pattern)
        elif check == "min_length":
            min_len = rule.get("min_length", 1)
            return F.length(F.col(col)) < min_len
        elif check == "min_value":
            return F.col(col) < rule.get("min_value")
        elif check == "max_value":
            return F.col(col) > rule.get("max_value")
        elif check == "allowed_values":
            allowed = rule.get("allowed_values", [])
            return ~F.col(col).isin(allowed)
        else:
            logger.warning(f"[DQ] Unknown check type: '{check}' — skipping")
            return None
