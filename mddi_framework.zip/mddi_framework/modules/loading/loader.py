# modules/loading/loader.py
# ─────────────────────────────────────────────
# MDDI — Data Loading Module
# Writes transformed data to configured target (Delta, JDBC, file)
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.connector_factory import ConnectorFactory
from delta.delta_writer import DeltaWriter
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics

logger = MDDILogger.get_logger(__name__)


class Loader:
    """Handles data loading into the configured target."""

    def __init__(self, spark: SparkSession, metrics: PipelineMetrics):
        self.spark = spark
        self.metrics = metrics

    def load(self, df: DataFrame, target_config: Dict[str, Any],
             connection_config: Dict[str, Any]) -> None:
        target_type = target_config.get("type", "delta").lower()
        write_mode = target_config.get("write_mode", "append")

        logger.info(f"[Loader] Target type={target_type} | mode={write_mode}")

        if target_type == "delta":
            writer = DeltaWriter(self.spark)
            writer.write(df, target_config)
        else:
            connector = ConnectorFactory.get_connector(
                target_type, connection_config, self.spark
            )
            connector.write(
                df=df,
                table=target_config.get("table"),
                schema=target_config.get("schema"),
                mode=write_mode,
                path=target_config.get("path"),
            )

        self.metrics.target_row_count = df.count()
        logger.info(f"[Loader] Loaded {self.metrics.target_row_count} rows")
