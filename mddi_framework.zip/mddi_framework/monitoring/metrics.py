# monitoring/metrics.py
# ─────────────────────────────────────────────
# MDDI — Pipeline Metrics Tracker
# Tracks row counts, durations, and failures per run
# ─────────────────────────────────────────────

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


@dataclass
class PipelineMetrics:
    pipeline_name: str
    run_id: str
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    source_row_count: int = 0
    target_row_count: int = 0
    quarantine_row_count: int = 0
    dq_pass_count: int = 0
    dq_fail_count: int = 0
    status: str = "RUNNING"
    error_message: Optional[str] = None

    @property
    def duration_seconds(self) -> float:
        end = self.end_time or time.time()
        return round(end - self.start_time, 2)

    def complete(self, status: str = "SUCCESS", error: str = None):
        self.end_time = time.time()
        self.status = status
        self.error_message = error
        logger.info(
            f"[Metrics] Pipeline={self.pipeline_name} | Status={self.status} | "
            f"Duration={self.duration_seconds}s | "
            f"Source={self.source_row_count} | Target={self.target_row_count} | "
            f"Quarantine={self.quarantine_row_count}"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pipeline_name": self.pipeline_name,
            "run_id": self.run_id,
            "status": self.status,
            "duration_seconds": self.duration_seconds,
            "source_row_count": self.source_row_count,
            "target_row_count": self.target_row_count,
            "quarantine_row_count": self.quarantine_row_count,
            "dq_pass_count": self.dq_pass_count,
            "dq_fail_count": self.dq_fail_count,
            "error_message": self.error_message,
            "run_date": datetime.utcnow().isoformat(),
        }

    def save_to_delta(self, spark):
        """Persist metrics to Delta Lake metrics table."""
        try:
            from pyspark.sql import Row
            row = Row(**self.to_dict())
            df = spark.createDataFrame([row])
            df.write.format("delta").mode("append").saveAsTable("mddi.pipeline_metrics")
        except Exception as e:
            logger.warning(f"Could not save metrics to Delta: {e}")
