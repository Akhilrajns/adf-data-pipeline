# monitoring/logger.py
# ─────────────────────────────────────────────
# MDDI — Structured Logger
# Writes to console + Delta Lake pipeline_logs table
# ─────────────────────────────────────────────

import logging
import json
from datetime import datetime
from typing import Optional


class MDDILogger:
    _loggers = {}

    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        if name in MDDILogger._loggers:
            return MDDILogger._loggers[name]

        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)

        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '{"time": "%(asctime)s", "level": "%(levelname)s", '
                '"module": "%(name)s", "message": "%(message)s"}'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        MDDILogger._loggers[name] = logger
        return logger

    @staticmethod
    def log_pipeline_event(spark, pipeline_name: str, event: str,
                           status: str, details: dict = None):
        """Persist a pipeline event to Delta Lake logs table."""
        try:
            from pyspark.sql import Row
            row = Row(
                pipeline_name=pipeline_name,
                event=event,
                status=status,
                details=json.dumps(details or {}),
                logged_at=datetime.utcnow().isoformat()
            )
            df = spark.createDataFrame([row])
            df.write.format("delta").mode("append").saveAsTable("mddi.pipeline_logs")
        except Exception as e:
            logging.getLogger(__name__).warning(f"Could not persist log to Delta: {e}")
