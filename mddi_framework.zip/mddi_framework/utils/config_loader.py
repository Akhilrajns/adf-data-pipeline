# utils/config_loader.py
# ─────────────────────────────────────────────
# MDDI — Config Loader
# Loads and resolves pipeline + global YAML configs
# Resolves ${ENV_VAR} placeholders from environment
# ─────────────────────────────────────────────

import os
import re
import yaml
from typing import Dict, Any
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)
ENV_VAR_PATTERN = re.compile(r"\$\{([^}]+)\}")


def _resolve_env_vars(value: Any) -> Any:
    """Recursively resolve ${ENV_VAR} placeholders in a config dict."""
    if isinstance(value, str):
        def replace(m):
            var = m.group(1)
            resolved = os.environ.get(var)
            if resolved is None:
                logger.warning(f"[Config] Env var not set: {var}")
            return resolved or m.group(0)
        return ENV_VAR_PATTERN.sub(replace, value)
    elif isinstance(value, dict):
        return {k: _resolve_env_vars(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [_resolve_env_vars(i) for i in value]
    return value


class ConfigLoader:

    def __init__(self, global_config_path: str = "config/global_config.yml",
                 connections_path: str = "config/connections.yml"):
        self.global_config = self._load(global_config_path)
        self.connections = self._load(connections_path).get("connections", {})

    def _load(self, path: str) -> Dict:
        with open(path, "r") as f:
            raw = yaml.safe_load(f)
        return _resolve_env_vars(raw)

    def load_pipeline(self, pipeline_path: str) -> Dict:
        """Load and resolve a pipeline YAML config."""
        config = self._load(pipeline_path)
        return config.get("pipeline", config)

    def get_connection(self, connection_ref: str) -> Dict:
        """Retrieve a resolved connection config by its reference name."""
        conn = self.connections.get(connection_ref)
        if not conn:
            raise KeyError(f"Connection '{connection_ref}' not found in connections.yml")
        return conn
