# utils/run_id.py
import uuid
from datetime import datetime


def generate_run_id(pipeline_name: str) -> str:
    """Generate a unique run ID for a pipeline execution."""
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    uid = str(uuid.uuid4())[:8]
    return f"{pipeline_name}_{ts}_{uid}"
