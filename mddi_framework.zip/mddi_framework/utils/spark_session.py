# utils/spark_session.py
# ─────────────────────────────────────────────
# MDDI — Spark Session Factory
# Creates a configured SparkSession for Databricks or local use
# ─────────────────────────────────────────────

from pyspark.sql import SparkSession


def get_spark(app_name: str = "MDDI_Pipeline",
              delta_enabled: bool = True) -> SparkSession:
    """
    Return an active SparkSession.
    On Databricks, returns the existing cluster session.
    Locally, creates a new session with Delta Lake support.
    """
    try:
        # On Databricks, SparkSession is pre-created
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
    except ImportError:
        builder = SparkSession.builder.appName(app_name)
        if delta_enabled:
            builder = (
                builder
                .config("spark.sql.extensions",
                        "io.delta.sql.DeltaSparkSessionExtension")
                .config("spark.sql.catalog.spark_catalog",
                        "org.apache.spark.sql.delta.catalog.DeltaCatalog")
            )
        spark = builder.getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    return spark
