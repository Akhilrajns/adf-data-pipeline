# MDDI Framework — Metadata-Driven Data Integration

AI-powered ETL migration and pipeline execution framework built on Databricks.
Converts Informatica PowerCenter/IICS jobs to Databricks pipelines via AI-driven XML → YAML conversion.

---

## Folder Structure

```
mddi_framework/
│
├── config/
│   ├── global_config.yml          # Global settings (env, Databricks, OpenAI, logging)
│   ├── connections.yml            # All source/target connection credentials
│   └── pipelines/
│       └── sample_pipeline.yml   # Example pipeline YAML definition
│
├── connectors/
│   ├── base_connector.py          # Abstract base class for all connectors
│   ├── connector_factory.py       # Factory: resolves connector type → class
│   ├── databases/
│   │   ├── mssql_connector.py     # SQL Server (JDBC)
│   │   ├── oracle_connector.py    # Oracle (JDBC)
│   │   ├── snowflake_connector.py # Snowflake (native connector)
│   │   └── postgres_connector.py  # PostgreSQL (JDBC)
│   └── files/
│       ├── parquet_connector.py   # Apache Parquet
│       ├── csv_connector.py       # CSV with configurable delimiter/encoding
│       ├── json_connector.py      # JSON (single-line and multi-line)
│       └── dat_connector.py       # Pipe-delimited / fixed-width DAT files
│
├── modules/
│   ├── pipeline_runner.py         # Main orchestrator — runs a full pipeline end-to-end
│   ├── extraction/
│   │   └── extractor.py           # Reads from any source connector
│   ├── transformation/
│   │   └── transformer.py         # Applies YAML-defined transformations
│   ├── loading/
│   │   └── loader.py              # Writes to Delta or any target connector
│   └── quality/
│       └── dq_engine.py           # Runs DQ rules → clean + quarantine DataFrames
│
├── ai/
│   ├── xml_to_yaml/
│   │   └── converter.py           # Azure OpenAI-powered XML → YAML converter
│   └── prompts/
│       └── xml_to_yaml_prompt.py  # Prompt template builder
│
├── validators/
│   └── yaml_validator.py          # JSON Schema validator for pipeline YAML files
│
├── sql/
│   ├── sql_executor.py            # Executes SQL files against SparkSession
│   ├── pre_actions/
│   │   └── customer_load_pre.sql  # Example: staging setup, audit log
│   └── post_actions/
│       └── customer_load_post.sql # Example: OPTIMIZE, VACUUM, watermark update
│
├── delta/
│   └── delta_writer.py            # Delta Lake writer: append / overwrite / MERGE
│
├── monitoring/
│   ├── logger.py                  # Structured JSON logger + Delta persistence
│   └── metrics.py                 # Per-run metrics: row counts, durations, DQ stats
│
├── utils/
│   ├── config_loader.py           # Loads & resolves YAML configs + env vars
│   ├── spark_session.py           # SparkSession factory (Databricks + local)
│   └── run_id.py                  # Unique run ID generator
│
└── tests/
    ├── conftest.py
    ├── fixtures/                  # Shared test data (XML samples, YAML templates)
    └── unit/
        ├── connectors/
        │   └── test_mssql_connector.py
        ├── modules/
        │   └── test_transformer.py
        ├── validators/
        │   └── test_yaml_validator.py
        └── ai/
            └── test_xml_to_yaml_prompt.py
```

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Validate a pipeline YAML
python -m validators.yaml_validator --file config/pipelines/sample_pipeline.yml

# Convert Informatica XML to YAML (single file)
python -m ai.xml_to_yaml.converter --input mappings/m_customer_load.xml --output config/pipelines/

# Convert a directory of XML files (batch)
python -m ai.xml_to_yaml.converter --input mappings/ --output config/pipelines/

# Run a pipeline
python -m modules.pipeline_runner --config config/pipelines/sample_pipeline.yml

# Run unit tests
pytest
```

---

## Pipeline Execution Flow

```
1. Validate YAML config
2. Run pre_actions SQL (staging setup, audit log)
3. Extract from source (MSSQL / Oracle / Snowflake / Parquet / CSV / JSON / DAT)
4. Apply transformations (rename, expression, filter, derive, cast, dedup)
5. Run data quality checks → clean + quarantine DataFrames
6. Save quarantine rows to mddi.quarantine Delta table
7. Load clean data to Delta Lake (append / overwrite / merge)
8. Run post_actions SQL (OPTIMIZE, VACUUM, watermark update)
9. Persist metrics to mddi.pipeline_metrics
10. Log pipeline event to mddi.pipeline_logs
```

---

## Supported Connectors

| Type       | Class                  | Protocol     |
|------------|------------------------|--------------|
| mssql      | MSSQLConnector         | JDBC         |
| oracle     | OracleConnector        | JDBC         |
| snowflake  | SnowflakeConnector     | Native       |
| postgres   | PostgresConnector      | JDBC         |
| parquet    | ParquetConnector       | File (ADLS)  |
| csv        | CSVConnector           | File (ADLS)  |
| json       | JSONConnector          | File (ADLS)  |
| dat        | DATConnector           | File (ADLS)  |
| delta      | DeltaWriter            | Delta Lake   |

---

## Supported Transformations

| Type           | Description                              |
|----------------|------------------------------------------|
| rename_columns | Rename column names via a mapping dict   |
| expression     | Add/overwrite columns with SQL exprs     |
| filter         | Drop rows using a SQL condition          |
| derive         | Alias for expression                     |
| drop_columns   | Remove columns from DataFrame            |
| cast_columns   | Cast column types                        |
| dedup          | Deduplicate rows (full or on subset)     |

---

## Data Quality Checks

| Check          | Description                              |
|----------------|------------------------------------------|
| not_null       | Column must not be null                  |
| unique         | Column values must be unique             |
| regex          | Column must match a regex pattern        |
| min_length     | String length must exceed minimum        |
| min_value      | Numeric value must exceed minimum        |
| max_value      | Numeric value must not exceed maximum    |
| allowed_values | Value must be in an allowed set          |

`on_failure` options: `quarantine` | `fail` | `warn`

---

## Environment Variables

| Variable                  | Description                        |
|---------------------------|------------------------------------|
| AZURE_OPENAI_ENDPOINT     | Azure OpenAI service endpoint      |
| AZURE_OPENAI_API_KEY      | Azure OpenAI API key               |
| AZURE_OPENAI_DEPLOYMENT   | Model deployment name (e.g. gpt-4o)|
| MSSQL_HOST / DB / USER / PASSWORD | SQL Server credentials    |
| ORACLE_HOST / SERVICE / USER / PASSWORD | Oracle credentials  |
| SF_ACCOUNT / WAREHOUSE / DATABASE / USER / PASSWORD | Snowflake |
| ADLS_ACCOUNT / CONTAINER / SAS_TOKEN | Azure Data Lake Storage |
