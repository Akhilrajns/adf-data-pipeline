# connectors/files/dat_connector.py
# ─────────────────────────────────────────────
# MDDI — Fixed-Width / DAT File Connector
# Supports pipe-delimited and fixed-width flat files
# ─────────────────────────────────────────────

from typing import Dict, Any, List, Optional
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class DATConnector(BaseConnector):
    """
    Reads pipe-delimited or fixed-width .dat files.
    For fixed-width, provide a `field_widths` list in config.
    """

    def read(self, path: str, delimiter: str = "|",
             field_widths: Optional[List[int]] = None,
             column_names: Optional[List[str]] = None, **kwargs) -> DataFrame:
        logger.info(f"[DAT] Reading from: {path}")

        if field_widths:
            return self._read_fixed_width(path, field_widths, column_names)

        options = {
            "sep": delimiter,
            "header": str(kwargs.get("header", False)).lower(),
            "inferSchema": "true",
            "encoding": kwargs.get("encoding", "UTF-8"),
        }
        df = self.spark.read.options(**options).csv(path)

        if column_names:
            df = df.toDF(*column_names)
        return df

    def _read_fixed_width(self, path: str, widths: List[int],
                          col_names: Optional[List[str]]) -> DataFrame:
        raw = self.spark.read.text(path)
        cols, pos = [], 0
        for i, w in enumerate(widths):
            name = col_names[i] if col_names else f"col_{i}"
            cols.append(F.trim(F.substring(F.col("value"), pos + 1, w)).alias(name))
            pos += w
        return raw.select(*cols)

    def write(self, df: DataFrame, path: str, delimiter: str = "|",
              mode: str = "overwrite", **kwargs) -> None:
        logger.info(f"[DAT] Writing to: {path}")
        df.write.option("sep", delimiter).mode(mode).csv(path)

    def test_connection(self) -> bool:
        return True
