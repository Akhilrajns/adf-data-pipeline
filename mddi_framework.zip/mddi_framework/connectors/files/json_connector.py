# connectors/files/json_connector.py
# ─────────────────────────────────────────────
# MDDI — JSON File Connector
# ─────────────────────────────────────────────

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger
from typing import Dict, Any, Optional

logger = MDDILogger.get_logger(__name__)


class JSONConnector(BaseConnector):

    def read(self, path: str, schema: Optional[StructType] = None,
             multiline: bool = False, **kwargs) -> DataFrame:
        logger.info(f"[JSON] Reading from: {path}")
        reader = self.spark.read.option("multiLine", str(multiline).lower())
        if schema:
            reader = reader.schema(schema)
        return reader.json(path)

    def write(self, df: DataFrame, path: str, mode: str = "overwrite", **kwargs) -> None:
        logger.info(f"[JSON] Writing to: {path}")
        df.write.mode(mode).json(path)

    def test_connection(self) -> bool:
        return True
