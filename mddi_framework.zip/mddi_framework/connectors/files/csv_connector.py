# connectors/files/csv_connector.py
# ─────────────────────────────────────────────
# MDDI — CSV File Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class CSVConnector(BaseConnector):

    DEFAULT_OPTIONS = {
        "header": "true",
        "inferSchema": "true",
        "sep": ",",
        "quote": '"',
        "escape": "\\",
        "multiLine": "false",
        "nullValue": "",
        "encoding": "UTF-8",
    }

    def read(self, path: str, **kwargs) -> DataFrame:
        options = {**self.DEFAULT_OPTIONS, **kwargs}
        logger.info(f"[CSV] Reading from: {path}")
        return self.spark.read.options(**options).csv(path)

    def write(self, df: DataFrame, path: str, mode: str = "overwrite",
              header: bool = True, sep: str = ",", **kwargs) -> None:
        logger.info(f"[CSV] Writing to: {path}")
        (
            df.write
            .option("header", str(header).lower())
            .option("sep", sep)
            .mode(mode)
            .csv(path)
        )

    def test_connection(self) -> bool:
        return True
