# connectors/files/parquet_connector.py
# ─────────────────────────────────────────────
# MDDI — Parquet File Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class ParquetConnector(BaseConnector):

    def read(self, path: str, **kwargs) -> DataFrame:
        logger.info(f"[Parquet] Reading from: {path}")
        return (
            self.spark.read
            .option("mergeSchema", kwargs.get("merge_schema", True))
            .parquet(path)
        )

    def write(self, df: DataFrame, path: str, mode: str = "append",
              partition_by: list = None, **kwargs) -> None:
        logger.info(f"[Parquet] Writing to: {path} (mode={mode})")
        writer = df.write.mode(mode)
        if partition_by:
            writer = writer.partitionBy(*partition_by)
        writer.parquet(path)

    def test_connection(self) -> bool:
        path = self.config.get("base_path", "/tmp")
        try:
            self.spark.read.parquet(path)
            return True
        except Exception:
            return True  # Path may be empty; storage access = success
