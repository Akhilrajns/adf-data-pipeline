# connectors/databases/snowflake_connector.py
# ─────────────────────────────────────────────
# MDDI — Snowflake Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class SnowflakeConnector(BaseConnector):

    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        super().__init__(config, spark)
        self.sf_options = {
            "sfURL": f"{config['account']}.snowflakecomputing.com",
            "sfWarehouse": config["warehouse"],
            "sfDatabase": config["database"],
            "sfSchema": config.get("schema", "PUBLIC"),
            "sfUser": config["username"],
            "sfPassword": config["password"],
            "sfRole": config.get("role", ""),
        }

    def read(self, table: str = None, query: str = None, **kwargs) -> DataFrame:
        options = {**self.sf_options}
        if query:
            options["query"] = query
        else:
            options["dbtable"] = table
        logger.info(f"[Snowflake] Reading: {table or 'custom query'}")
        return self.spark.read.format("snowflake").options(**options).load()

    def write(self, df: DataFrame, table: str, mode: str = "append", **kwargs) -> None:
        logger.info(f"[Snowflake] Writing to {table}")
        (
            df.write.format("snowflake")
            .options(**self.sf_options)
            .option("dbtable", table)
            .mode(mode)
            .save()
        )

    def test_connection(self) -> bool:
        try:
            self.read(query="SELECT CURRENT_TIMESTAMP()")
            return True
        except Exception as e:
            logger.error(f"[Snowflake] Connection test failed: {e}")
            return False
