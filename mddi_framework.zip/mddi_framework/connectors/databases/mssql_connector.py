# connectors/databases/mssql_connector.py
# ─────────────────────────────────────────────
# MDDI — Microsoft SQL Server Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class MSSQLConnector(BaseConnector):

    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        super().__init__(config, spark)
        self.jdbc_url = (
            f"jdbc:sqlserver://{config['host']}:{config.get('port', 1433)};"
            f"databaseName={config['database']};"
            "encrypt=true;trustServerCertificate=true"
        )
        self.props = {
            "user": config["username"],
            "password": config["password"],
            "driver": config.get("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver"),
        }

    def read(self, table: str = None, query: str = None,
             schema: str = "dbo", **kwargs) -> DataFrame:
        dbtable = f"({query}) AS subq" if query else f"{schema}.{table}"
        logger.info(f"[MSSQL] Reading: {dbtable}")
        return (
            self.spark.read.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .option("fetchsize", kwargs.get("fetchsize", 10000))
            .option("numPartitions", kwargs.get("numPartitions", 8))
            .load()
        )

    def write(self, df: DataFrame, table: str, schema: str = "dbo",
              mode: str = "append", **kwargs) -> None:
        dbtable = f"{schema}.{table}"
        logger.info(f"[MSSQL] Writing {df.count()} rows to {dbtable}")
        (
            df.write.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .option("batchsize", kwargs.get("batchsize", 5000))
            .mode(mode)
            .save()
        )

    def test_connection(self) -> bool:
        try:
            self.read(query="SELECT 1 AS test")
            return True
        except Exception as e:
            logger.error(f"[MSSQL] Connection test failed: {e}")
            return False
