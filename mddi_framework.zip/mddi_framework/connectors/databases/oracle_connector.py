# connectors/databases/oracle_connector.py
# ─────────────────────────────────────────────
# MDDI — Oracle Database Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class OracleConnector(BaseConnector):

    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        super().__init__(config, spark)
        self.jdbc_url = (
            f"jdbc:oracle:thin:@{config['host']}:{config.get('port', 1521)}"
            f":{config.get('service_name', '')}"
        )
        self.props = {
            "user": config["username"],
            "password": config["password"],
            "driver": "oracle.jdbc.OracleDriver",
        }

    def read(self, table: str = None, query: str = None,
             schema: str = None, **kwargs) -> DataFrame:
        if query:
            dbtable = f"({query}) subq"
        elif schema:
            dbtable = f"{schema}.{table}"
        else:
            dbtable = table
        logger.info(f"[Oracle] Reading: {dbtable}")
        return (
            self.spark.read.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .option("fetchsize", kwargs.get("fetchsize", 10000))
            .load()
        )

    def write(self, df: DataFrame, table: str, schema: str = None,
              mode: str = "append", **kwargs) -> None:
        dbtable = f"{schema}.{table}" if schema else table
        logger.info(f"[Oracle] Writing to {dbtable}")
        (
            df.write.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .mode(mode)
            .save()
        )

    def test_connection(self) -> bool:
        try:
            self.read(query="SELECT 1 FROM DUAL")
            return True
        except Exception as e:
            logger.error(f"[Oracle] Connection test failed: {e}")
            return False
