# connectors/databases/postgres_connector.py
# ─────────────────────────────────────────────
# MDDI — PostgreSQL Connector
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession
from connectors.base_connector import BaseConnector
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class PostgresConnector(BaseConnector):

    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        super().__init__(config, spark)
        self.jdbc_url = (
            f"jdbc:postgresql://{config['host']}:{config.get('port', 5432)}"
            f"/{config['database']}"
        )
        self.props = {
            "user": config["username"],
            "password": config["password"],
            "driver": "org.postgresql.Driver",
        }

    def read(self, table: str = None, query: str = None,
             schema: str = "public", **kwargs) -> DataFrame:
        dbtable = f"({query}) AS subq" if query else f"{schema}.{table}"
        logger.info(f"[Postgres] Reading: {dbtable}")
        return (
            self.spark.read.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .load()
        )

    def write(self, df: DataFrame, table: str, schema: str = "public",
              mode: str = "append", **kwargs) -> None:
        dbtable = f"{schema}.{table}"
        logger.info(f"[Postgres] Writing to {dbtable}")
        (
            df.write.format("jdbc")
            .option("url", self.jdbc_url)
            .option("dbtable", dbtable)
            .option("user", self.props["user"])
            .option("password", self.props["password"])
            .option("driver", self.props["driver"])
            .mode(mode)
            .save()
        )

    def test_connection(self) -> bool:
        try:
            self.read(query="SELECT 1")
            return True
        except Exception as e:
            logger.error(f"[Postgres] Connection test failed: {e}")
            return False
