# connectors/base_connector.py
from abc import ABC, abstractmethod
from typing import Dict, Any
from pyspark.sql import DataFrame, SparkSession


class BaseConnector(ABC):
    """Abstract base for all MDDI source/target connectors."""

    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        self.config = config
        self.spark = spark
        self.connection_name = config.get("name", "unknown")

    @abstractmethod
    def read(self, **kwargs) -> DataFrame:
        pass

    @abstractmethod
    def write(self, df: DataFrame, **kwargs) -> None:
        pass

    @abstractmethod
    def test_connection(self) -> bool:
        pass
