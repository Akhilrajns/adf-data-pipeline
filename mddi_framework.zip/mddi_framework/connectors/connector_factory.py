# connectors/connector_factory.py
# ─────────────────────────────────────────────
# MDDI — Connector Factory
# Resolves the correct connector from connection type string
# ─────────────────────────────────────────────

from typing import Dict, Any
from pyspark.sql import SparkSession
from connectors.base_connector import BaseConnector


CONNECTOR_REGISTRY = {
    "mssql": "connectors.databases.mssql_connector.MSSQLConnector",
    "oracle": "connectors.databases.oracle_connector.OracleConnector",
    "snowflake": "connectors.databases.snowflake_connector.SnowflakeConnector",
    "postgres": "connectors.databases.postgres_connector.PostgresConnector",
    "parquet": "connectors.files.parquet_connector.ParquetConnector",
    "csv": "connectors.files.csv_connector.CSVConnector",
    "json": "connectors.files.json_connector.JSONConnector",
    "dat": "connectors.files.dat_connector.DATConnector",
    "delta": "delta.delta_writer.DeltaConnector",
}


class ConnectorFactory:
    @staticmethod
    def get_connector(conn_type: str, config: Dict[str, Any],
                      spark: SparkSession) -> BaseConnector:
        module_path = CONNECTOR_REGISTRY.get(conn_type.lower())
        if not module_path:
            raise ValueError(
                f"Unknown connector type: '{conn_type}'. "
                f"Available: {list(CONNECTOR_REGISTRY.keys())}"
            )
        module_name, class_name = module_path.rsplit(".", 1)
        import importlib
        module = importlib.import_module(module_name)
        cls = getattr(module, class_name)
        return cls(config=config, spark=spark)
