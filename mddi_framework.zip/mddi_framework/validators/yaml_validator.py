# validators/yaml_validator.py
# ─────────────────────────────────────────────
# MDDI — YAML Pipeline Validator
# Validates pipeline YAML against the MDDI schema
# Run: python -m validators.yaml_validator --file path/to/pipeline.yml
# ─────────────────────────────────────────────

import argparse
import yaml
import jsonschema
from typing import Dict, Any, List
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)

# ── JSON Schema for MDDI Pipeline YAML ───────────────────────────────────────

PIPELINE_SCHEMA = {
    "type": "object",
    "required": ["pipeline"],
    "properties": {
        "pipeline": {
            "type": "object",
            "required": ["name", "source", "target"],
            "properties": {
                "name": {"type": "string", "minLength": 1},
                "description": {"type": "string"},
                "version": {"type": "string"},
                "owner": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},

                "source": {
                    "type": "object",
                    "required": ["type"],
                    "properties": {
                        "type": {
                            "type": "string",
                            "enum": ["mssql", "oracle", "snowflake", "postgres",
                                     "parquet", "csv", "json", "dat", "delta"]
                        },
                        "connection_ref": {"type": "string"},
                        "schema": {"type": "string"},
                        "table": {"type": "string"},
                        "query": {"type": "string"},
                        "path": {"type": "string"},
                    }
                },

                "transformations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["type"],
                        "properties": {
                            "type": {
                                "type": "string",
                                "enum": ["rename_columns", "expression", "filter",
                                         "derive", "drop_columns", "cast_columns", "dedup"]
                            }
                        }
                    }
                },

                "data_quality": {
                    "type": "object",
                    "properties": {
                        "rules": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "required": ["column", "checks"],
                                "properties": {
                                    "column": {"type": "string"},
                                    "checks": {
                                        "type": "array",
                                        "items": {
                                            "type": "string",
                                            "enum": ["not_null", "unique", "regex",
                                                     "min_length", "min_value",
                                                     "max_value", "allowed_values"]
                                        }
                                    }
                                }
                            }
                        },
                        "on_failure": {
                            "type": "string",
                            "enum": ["quarantine", "fail", "warn"]
                        }
                    }
                },

                "target": {
                    "type": "object",
                    "required": ["type", "table"],
                    "properties": {
                        "type": {
                            "type": "string",
                            "enum": ["delta", "mssql", "oracle", "snowflake",
                                     "postgres", "parquet", "csv"]
                        },
                        "layer": {
                            "type": "string",
                            "enum": ["bronze", "silver", "gold"]
                        },
                        "database": {"type": "string"},
                        "schema": {"type": "string"},
                        "table": {"type": "string"},
                        "write_mode": {
                            "type": "string",
                            "enum": ["append", "overwrite", "merge"]
                        },
                        "merge_keys": {"type": "array", "items": {"type": "string"}},
                        "partition_by": {"type": "array", "items": {"type": "string"}},
                    }
                },

                "pre_actions": {"type": "array", "items": {"type": "string"}},
                "post_actions": {"type": "array", "items": {"type": "string"}},
            }
        }
    }
}


class YAMLValidator:

    def validate(self, yaml_path: str) -> List[str]:
        """
        Validate a pipeline YAML file against the MDDI schema.
        Returns a list of error messages (empty = valid).
        """
        errors = []
        try:
            with open(yaml_path, "r") as f:
                config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            return [f"YAML parse error: {e}"]

        validator = jsonschema.Draft7Validator(PIPELINE_SCHEMA)
        for error in sorted(validator.iter_errors(config), key=lambda e: e.path):
            path = " → ".join(str(p) for p in error.path) or "root"
            errors.append(f"[{path}] {error.message}")

        if errors:
            logger.error(f"[Validator] {len(errors)} error(s) in {yaml_path}")
            for e in errors:
                logger.error(f"  ✗ {e}")
        else:
            logger.info(f"[Validator] ✓ {yaml_path} is valid")

        return errors


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MDDI YAML Validator")
    parser.add_argument("--file", required=True, help="Path to pipeline YAML")
    args = parser.parse_args()

    validator = YAMLValidator()
    errors = validator.validate(args.file)
    exit(1 if errors else 0)
