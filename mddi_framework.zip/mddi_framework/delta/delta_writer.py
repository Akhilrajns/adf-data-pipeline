# delta/delta_writer.py
# ─────────────────────────────────────────────
# MDDI — Delta Lake Writer
# Handles append, overwrite, and MERGE (upsert) to Delta tables
# Supports Bronze / Silver / Gold layers
# ─────────────────────────────────────────────

from typing import Dict, Any, List
from pyspark.sql import DataFrame, SparkSession
from delta.tables import DeltaTable
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class DeltaWriter:

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def write(self, df: DataFrame, target_config: Dict[str, Any]) -> None:
        """
        Route to the correct write strategy based on target config.
        Modes: append | overwrite | merge
        """
        database = target_config.get("database", "main")
        schema = target_config.get("schema", "bronze")
        table = target_config["table"]
        full_table = f"{database}.{schema}.{table}"
        mode = target_config.get("write_mode", "append").lower()
        partition_by = target_config.get("partition_by", [])
        merge_keys = target_config.get("merge_keys", [])

        logger.info(f"[Delta] Writing to {full_table} | mode={mode}")

        if mode == "merge":
            if not merge_keys:
                raise ValueError("[Delta] merge_keys required for merge write mode.")
            self._merge(df, full_table, merge_keys)
        else:
            writer = df.write.format("delta").mode(mode)
            if partition_by:
                writer = writer.partitionBy(*partition_by)
            writer.option("mergeSchema", "true").saveAsTable(full_table)

        logger.info(f"[Delta] Write complete → {full_table}")

    def _merge(self, df: DataFrame, full_table: str, merge_keys: List[str]) -> None:
        """Perform a MERGE (upsert) operation using Delta Lake merge API."""
        join_condition = " AND ".join(
            [f"target.{k} = source.{k}" for k in merge_keys]
        )
        update_set = {c: f"source.{c}" for c in df.columns if c not in merge_keys}
        insert_set = {c: f"source.{c}" for c in df.columns}

        if DeltaTable.isDeltaTable(self.spark, full_table):
            delta_table = DeltaTable.forName(self.spark, full_table)
            (
                delta_table.alias("target")
                .merge(df.alias("source"), join_condition)
                .whenMatchedUpdate(set=update_set)
                .whenNotMatchedInsert(values=insert_set)
                .execute()
            )
            logger.info(f"[Delta] MERGE complete on {full_table}")
        else:
            logger.info(f"[Delta] Table {full_table} not found — creating via initial load")
            df.write.format("delta").mode("overwrite").saveAsTable(full_table)

    def save_quarantine(self, df: DataFrame, pipeline_name: str) -> None:
        """Save DQ-failed rows to the quarantine table."""
        if df is None or df.count() == 0:
            return
        from pyspark.sql import functions as F
        df = df.withColumn("pipeline_name", F.lit(pipeline_name))
        df = df.withColumn("quarantine_ts", F.current_timestamp())
        full_table = f"mddi.quarantine"
        df.write.format("delta").mode("append").option("mergeSchema", "true") \
            .saveAsTable(full_table)
        logger.info(f"[Delta] Quarantine rows saved to {full_table}")
