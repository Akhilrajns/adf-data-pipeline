# ai/xml_to_yaml/converter.py
# ─────────────────────────────────────────────
# MDDI — AI-Driven XML → YAML Converter
# Parses Informatica PowerCenter/IICS XML exports
# and calls Azure OpenAI to generate MDDI pipeline YAML
# ─────────────────────────────────────────────

import os
import yaml
import argparse
from pathlib import Path
from lxml import etree
from openai import AzureOpenAI
from ai.prompts.xml_to_yaml_prompt import build_prompt
from validators.yaml_validator import YAMLValidator
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)


class XMLToYAMLConverter:
    """
    Converts Informatica XML mapping/workflow definitions
    into MDDI pipeline YAML files using Azure OpenAI.
    """

    def __init__(self):
        self.client = AzureOpenAI(
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        )
        self.deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
        self.validator = YAMLValidator()

    def convert(self, xml_path: str, output_dir: str,
                validate: bool = True) -> str:
        """
        Convert a single Informatica XML file to an MDDI pipeline YAML.

        Returns:
            Path to the generated YAML file.
        """
        xml_content = self._read_xml(xml_path)
        metadata = self._extract_metadata(xml_content)

        logger.info(f"[Converter] Processing: {xml_path}")
        logger.info(f"[Converter] Extracted metadata: {list(metadata.keys())}")

        prompt = build_prompt(xml_content, metadata)
        yaml_content = self._call_openai(prompt)

        output_path = self._save_yaml(yaml_content, xml_path, output_dir)

        if validate:
            errors = self.validator.validate(output_path)
            if errors:
                logger.warning(
                    f"[Converter] Generated YAML has {len(errors)} validation issue(s)."
                    " Review before use."
                )

        return output_path

    def convert_batch(self, xml_dir: str, output_dir: str) -> list:
        """Convert all XML files in a directory."""
        xml_files = list(Path(xml_dir).glob("**/*.xml"))
        results = []
        for xml_file in xml_files:
            try:
                out = self.convert(str(xml_file), output_dir)
                results.append({"file": str(xml_file), "output": out, "status": "success"})
            except Exception as e:
                logger.error(f"[Converter] Failed: {xml_file} — {e}")
                results.append({"file": str(xml_file), "error": str(e), "status": "failed"})
        return results

    def _read_xml(self, path: str) -> str:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    def _extract_metadata(self, xml_content: str) -> dict:
        """Parse key metadata from XML to assist the prompt."""
        root = etree.fromstring(xml_content.encode())
        metadata = {
            "mapping_names": [e.get("NAME") for e in root.findall(".//MAPPING")],
            "workflow_names": [e.get("NAME") for e in root.findall(".//WORKFLOW")],
            "source_tables": [e.get("NAME") for e in root.findall(".//SOURCE")],
            "target_tables": [e.get("NAME") for e in root.findall(".//TARGET")],
            "transformation_types": list({
                e.get("TYPE") for e in root.findall(".//TRANSFORMATION")
            }),
        }
        return metadata

    def _call_openai(self, prompt: str) -> str:
        """Send the extraction prompt to Azure OpenAI and return the YAML string."""
        logger.info(f"[Converter] Calling Azure OpenAI ({self.deployment})")
        response = self.client.chat.completions.create(
            model=self.deployment,
            messages=[
                {"role": "system", "content": (
                    "You are an expert data engineer specializing in Informatica to "
                    "Databricks migrations. Generate only valid YAML. No markdown fences."
                )},
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
            max_tokens=4096,
        )
        return response.choices[0].message.content.strip()

    def _save_yaml(self, yaml_content: str, xml_path: str, output_dir: str) -> str:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        stem = Path(xml_path).stem
        out_path = os.path.join(output_dir, f"{stem}_pipeline.yml")
        with open(out_path, "w") as f:
            f.write(yaml_content)
        logger.info(f"[Converter] YAML saved: {out_path}")
        return out_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MDDI XML to YAML Converter")
    parser.add_argument("--input", required=True, help="XML file or directory")
    parser.add_argument("--output", required=True, help="Output directory for YAML files")
    parser.add_argument("--no-validate", action="store_true")
    args = parser.parse_args()

    converter = XMLToYAMLConverter()
    if Path(args.input).is_dir():
        results = converter.convert_batch(args.input, args.output)
        success = sum(1 for r in results if r["status"] == "success")
        print(f"Converted {success}/{len(results)} files successfully.")
    else:
        converter.convert(args.input, args.output, validate=not args.no_validate)
