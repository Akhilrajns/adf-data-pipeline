# ai/prompts/xml_to_yaml_prompt.py
# ─────────────────────────────────────────────
# MDDI — Prompt Builder for XML → YAML conversion
# ─────────────────────────────────────────────

from typing import Dict


SYSTEM_CONTEXT = """
You are converting Informatica PowerCenter/IICS XML definitions
into MDDI pipeline YAML files. The YAML must strictly follow this structure:

pipeline:
  name: <snake_case_name>
  description: <description>
  version: "1.0"
  owner: data-engineering

  source:
    type: mssql | oracle | snowflake | postgres | parquet | csv | json | dat | delta
    connection_ref: <ref>
    schema: <schema>
    table: <table>
    query: <optional SQL>

  pre_actions:
    - sql/pre_actions/<name>.sql

  transformations:
    - type: rename_columns | expression | filter | derive | drop_columns | cast_columns | dedup
      <type-specific fields>

  data_quality:
    rules:
      - column: <col>
        checks: [not_null, unique, regex, min_length, min_value, max_value, allowed_values]
    on_failure: quarantine | fail | warn

  target:
    type: delta
    layer: bronze | silver | gold
    database: main
    schema: <layer>
    table: <table>
    write_mode: append | overwrite | merge
    merge_keys: [<key_cols>]
    partition_by: [<partition_cols>]

  post_actions:
    - sql/post_actions/<name>.sql

Rules:
- Output ONLY valid YAML. No markdown, no backticks, no explanations.
- Map Informatica transformation types to MDDI transformation types.
- Infer data quality rules from column names and transformation logic.
- Use snake_case for all names.
- If source DB type is ambiguous, default to mssql.
"""


def build_prompt(xml_content: str, metadata: Dict) -> str:
    return f"""
{SYSTEM_CONTEXT}

--- METADATA EXTRACTED FROM XML ---
Mapping Names: {metadata.get('mapping_names')}
Workflow Names: {metadata.get('workflow_names')}
Source Tables: {metadata.get('source_tables')}
Target Tables: {metadata.get('target_tables')}
Transformation Types: {metadata.get('transformation_types')}

--- FULL INFORMATICA XML ---
{xml_content}

--- GENERATE MDDI PIPELINE YAML BELOW ---
"""
