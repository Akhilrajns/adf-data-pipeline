# monitoring/logger.py
# ─────────────────────────────────────────────
# MDDI — Structured Logger
# JSON-formatted logging to console.
# When Spark is available, also persists to Delta pipeline_logs table.
# ─────────────────────────────────────────────

import logging
import json
from datetime import datetime


class MDDILogger:
    _loggers: dict = {}

    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        if name in MDDILogger._loggers:
            return MDDILogger._loggers[name]

        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                '{"ts":"%(asctime)s","level":"%(levelname)s",'
                '"module":"%(name)s","msg":"%(message)s"}'
            ))
            logger.addHandler(handler)
        MDDILogger._loggers[name] = logger
        return logger

    @staticmethod
    def log_pipeline_event(spark, pipeline_name: str, event: str,
                           status: str, details: dict = None) -> None:
        """Persist a pipeline lifecycle event to mddi.pipeline_logs Delta table."""
        try:
            from pyspark.sql import Row
            row = Row(
                pipeline_name=pipeline_name,
                event=event,
                status=status,
                details=json.dumps(details or {}),
                logged_at=datetime.utcnow().isoformat(),
            )
            spark.createDataFrame([row]).write \
                .format("delta").mode("append") \
                .saveAsTable("mddi.pipeline_logs")
        except Exception as e:
            logging.getLogger(__name__).warning(
                f"Could not persist log event to Delta: {e}"
            )
