# pipeline_runner.py
# ─────────────────────────────────────────────
# MDDI — Pipeline Runner (Main Orchestrator)
#
# Reads the pipeline YAML and executes only the steps listed in
# dataFlowExecutionSequence — in the exact order defined.
#
# Supported steps:
#   DataExtraction     → reads all sources in dataExtractionRef
#   DataValidation     → applies dataValidationRef rules per source
#   DataTransformation → executes dataTransformationRef.executionSequence
#   DataLoad           → writes to all targets in dataLoadRef
#
# Steps NOT listed in dataFlowExecutionSequence are completely skipped.
#
# Usage:
#   python pipeline_runner.py --config config/pipelines/extract_validate_transform_load.yml
#
# Minimal pipeline (extract + load only):
#   dataFlowExecutionSequence:
#     - DataExtraction
#     - DataLoad
# ─────────────────────────────────────────────

import argparse
import sys
from typing import Dict, Optional
from pyspark.sql import DataFrame

from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics
from utils.config_loader import PipelineConfig
from utils.spark_session import get_spark
from utils.run_id import generate_run_id
from validators.yaml_validator import YAMLValidator
from steps.data_extraction import DataExtractionStep
from steps.data_validation import DataValidationStep
from steps.data_transformation import DataTransformationStep
from steps.data_load import DataLoadStep

logger = MDDILogger.get_logger(__name__)

# Canonical step name constants — must match dataFlowExecutionSequence values
STEP_DATA_EXTRACTION     = "DataExtraction"
STEP_DATA_VALIDATION     = "DataValidation"
STEP_DATA_TRANSFORMATION = "DataTransformation"
STEP_DATA_LOAD           = "DataLoad"

ALL_VALID_STEPS = [
    STEP_DATA_EXTRACTION,
    STEP_DATA_VALIDATION,
    STEP_DATA_TRANSFORMATION,
    STEP_DATA_LOAD,
]


class PipelineRunner:
    """
    Orchestrates pipeline execution driven by dataFlowExecutionSequence.
    Each step is a self-contained class in steps/.
    State (DataFrames) is passed between steps via in-memory dicts.
    """

    def __init__(self, config_path: str):
        # ── Validate YAML before loading ──────────────────────────────────────
        errors = YAMLValidator().validate(config_path)
        if errors:
            logger.error(
                f"[Runner] Pipeline YAML validation failed with "
                f"{len(errors)} error(s). Aborting."
            )
            for e in errors:
                logger.error(f"  ✗ {e}")
            raise ValueError(
                f"Invalid pipeline YAML: {config_path}. "
                f"Fix {len(errors)} error(s) before running."
            )

        self.config   = PipelineConfig(config_path)
        self.spark    = get_spark(app_name=self.config.label)
        self.run_id   = generate_run_id(self.config.label)
        self.metrics  = PipelineMetrics(
            pipeline_name=self.config.label,
            run_id=self.run_id,
        )

    # ── Public entry point ────────────────────────────────────────────────────

    def run(self) -> PipelineMetrics:
        """
        Execute the pipeline.
        Returns PipelineMetrics with final status and row counts.
        """
        if not self.config.is_active:
            logger.warning(
                f"[Runner] Pipeline '{self.config.label}' is marked "
                "isActive=false — skipping execution."
            )
            self.metrics.complete(status="SKIPPED")
            return self.metrics

        sequence = self._resolve_and_validate_sequence()

        self._log_header(sequence)

        # Step state passed between steps
        sources: Dict[str, DataFrame] = {}   # { source_name: DataFrame }
        current_df: Optional[DataFrame] = None

        try:
            for step_name in sequence:

                # ── DataExtraction ─────────────────────────────────────────────
                if step_name == STEP_DATA_EXTRACTION:
                    logger.info(self._step_banner(STEP_DATA_EXTRACTION))
                    extractor = DataExtractionStep(
                        spark=self.spark,
                        config=self.config,
                        metrics=self.metrics,
                    )
                    sources    = extractor.execute()
                    current_df = next(iter(sources.values()))

                # ── DataValidation ─────────────────────────────────────────────
                elif step_name == STEP_DATA_VALIDATION:
                    logger.info(self._step_banner(STEP_DATA_VALIDATION))
                    validator = DataValidationStep(
                        spark=self.spark,
                        config=self.config,
                        metrics=self.metrics,
                    )
                    sources    = validator.execute(sources)
                    current_df = next(iter(sources.values()), current_df)

                # ── DataTransformation ─────────────────────────────────────────
                elif step_name == STEP_DATA_TRANSFORMATION:
                    logger.info(self._step_banner(STEP_DATA_TRANSFORMATION))
                    transformer = DataTransformationStep(
                        spark=self.spark,
                        config=self.config,
                    )
                    current_df = transformer.execute(sources)

                # ── DataLoad ───────────────────────────────────────────────────
                elif step_name == STEP_DATA_LOAD:
                    logger.info(self._step_banner(STEP_DATA_LOAD))
                    loader = DataLoadStep(
                        spark=self.spark,
                        config=self.config,
                        metrics=self.metrics,
                    )
                    loader.execute(current_df)

            # ── Success ────────────────────────────────────────────────────────
            self.metrics.complete(status="SUCCESS")
            MDDILogger.log_pipeline_event(
                self.spark, self.config.label,
                "PIPELINE_COMPLETE", "SUCCESS",
                details=self.metrics.to_dict(),
            )

        except Exception as exc:
            logger.error(f"[Runner] Pipeline FAILED: {exc}", exc_info=True)
            self.metrics.complete(status="FAILED", error=str(exc))
            MDDILogger.log_pipeline_event(
                self.spark, self.config.label,
                "PIPELINE_FAILED", "FAILED",
                details={"error": str(exc)},
            )
            raise

        finally:
            self.metrics.save_to_delta(self.spark)
            logger.info(
                f"[Runner] ══ END ══ | {self.config.label} | "
                f"Status={self.metrics.status} | "
                f"Duration={self.metrics.duration_seconds}s"
            )

        return self.metrics

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _resolve_and_validate_sequence(self) -> list:
        """
        Read dataFlowExecutionSequence from the YAML.
        Validates step names. Falls back to [DataExtraction, DataLoad] if empty.
        """
        sequence = self.config.data_flow_execution_sequence

        if not sequence:
            logger.warning(
                "[Runner] dataFlowExecutionSequence not defined — "
                "defaulting to [DataExtraction, DataLoad]"
            )
            return [STEP_DATA_EXTRACTION, STEP_DATA_LOAD]

        invalid = [s for s in sequence if s not in ALL_VALID_STEPS]
        if invalid:
            raise ValueError(
                f"[Runner] Unknown step(s) in dataFlowExecutionSequence: {invalid}. "
                f"Valid values: {ALL_VALID_STEPS}"
            )

        return sequence

    @staticmethod
    def _step_banner(step_name: str) -> str:
        return f"{'─' * 50}\n[Runner] STEP: {step_name}\n{'─' * 50}"

    def _log_header(self, sequence: list) -> None:
        logger.info("=" * 60)
        logger.info(f"[Runner] START | {self.config.label}")
        logger.info(f"[Runner] run_id: {self.run_id}")
        logger.info(f"[Runner] Steps : {' → '.join(sequence)}")
        logger.info("=" * 60)


# ── CLI entry point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="MDDI Pipeline Runner",
        epilog=(
            "The pipeline YAML's dataFlowExecutionSequence determines "
            "which steps are executed and in what order."
        )
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to pipeline YAML (e.g. config/pipelines/my_pipeline.yml)"
    )
    args = parser.parse_args()

    try:
        runner = PipelineRunner(config_path=args.config)
        metrics = runner.run()
        sys.exit(0 if metrics.status == "SUCCESS" else 1)
    except Exception as e:
        logger.error(f"Pipeline execution failed: {e}")
        sys.exit(1)
