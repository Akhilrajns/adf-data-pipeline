# validators/yaml_validator.py
# ─────────────────────────────────────────────
# MDDI — YAML Pipeline Validator
#
# Validates a pipeline YAML file against the MDDI schema before execution.
# Schema mirrors the exact field names and structure of the reference YAML:
#   metadataConfig → sourceMetadataRef, targetMetadataRef,
#   dataExtractionRef, dataValidationRef, dataTransformationRef,
#   dataLoadRef, dataMappingRef, dataFlowExecutionSequence
#
# Run standalone:
#   python -m validators.yaml_validator --file config/pipelines/my_pipeline.yml
# ─────────────────────────────────────────────

import argparse
import yaml
import jsonschema
from typing import List
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)

# ── JSON Schema ───────────────────────────────────────────────────────────────

MDDI_PIPELINE_SCHEMA = {
    "type": "object",
    "required": ["metadataConfig"],
    "properties": {
        "metadataConfig": {
            "type": "object",
            "required": ["label", "dataExtractionRef", "dataLoadRef",
                         "dataFlowExecutionSequence"],
            "properties": {

                "label":          {"type": "string", "minLength": 1},
                "isActive":       {"type": "boolean"},
                "isAuditEnabled": {"type": "boolean"},
                "audit":          {"type": "string"},

                # ── versionHistory ────────────────────────────────────────────
                "versionHistory": {
                    "type": "array",
                    "items": {"type": "object"}
                },

                # ── sourceMetadataRef ─────────────────────────────────────────
                "sourceMetadataRef": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "attributes"],
                        "properties": {
                            "name": {"type": "string"},
                            "numberOfAttributes": {"type": "integer"},
                            "attributes": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "required": ["attributeName", "attributeType"],
                                    "properties": {
                                        "attributeName":  {"type": "string"},
                                        "attributeType":  {"type": "string"},
                                        "attributeLength": {"type": "integer"},
                                        "precision":      {"type": "integer"},
                                    }
                                }
                            }
                        }
                    }
                },

                # ── targetMetadataRef ─────────────────────────────────────────
                "targetMetadataRef": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "attributes"],
                        "properties": {
                            "name": {"type": "string"},
                            "numberOfAttributes": {"type": "integer"},
                            "attributes": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "required": ["attributeName", "attributeType"],
                                    "properties": {
                                        "attributePosition": {"type": "integer"},
                                        "attributeName":     {"type": "string"},
                                        "attributeType":     {"type": "string"},
                                        "attributeLength":   {"type": "integer"},
                                        "precision":         {"type": "integer"},
                                    }
                                }
                            }
                        }
                    }
                },

                # ── dataExtractionRef ─────────────────────────────────────────
                "dataExtractionRef": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "required": ["dataSourceType", "dataSourceName"],
                        "properties": {
                            "dataSourceType": {
                                "type": "string",
                                "enum": ["File", "Database"]
                            },
                            "dataSourceFilePath": {"type": "string"},
                            "dataSourceName":     {"type": "string"},
                            "connection_ref":     {"type": "string"},
                            "sqlQueryRef": {
                                "type": "object",
                                "properties": {
                                    "isActive": {"type": "boolean"},
                                    "query":    {"type": "string"},
                                }
                            }
                        }
                    }
                },

                # ── dataValidationRef ─────────────────────────────────────────
                "dataValidationRef": {
                    "type": "object",
                    "properties": {
                        "isActive": {"type": "boolean"},
                        "rules": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "required": ["sourceName", "checkType", "severity"],
                                "properties": {
                                    "sourceName": {"type": "string"},
                                    "checkType": {
                                        "type": "string",
                                        "enum": ["NOT_NULL", "UNIQUE", "ROW_COUNT",
                                                 "REGEX", "MIN_VALUE", "MAX_VALUE"]
                                    },
                                    "column":   {"type": "string"},
                                    "severity": {
                                        "type": "string",
                                        "enum": ["ERROR", "WARN"]
                                    },
                                    "minRows":        {"type": "integer"},
                                    "regex_pattern":  {"type": "string"},
                                    "min_value":      {"type": "number"},
                                    "max_value":      {"type": "number"},
                                }
                            }
                        }
                    }
                },

                # ── dataTransformationRef ─────────────────────────────────────
                "dataTransformationRef": {
                    "type": "object",
                    "properties": {
                        "dataJoinRef": {
                            "type": "object",
                            "properties": {
                                "isActive": {"type": "boolean"},
                                "joins": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["id", "joinType", "sourceName"],
                                        "properties": {
                                            "id":              {"type": "integer"},
                                            "joinType": {
                                                "type": "string",
                                                "enum": ["inner", "left", "right",
                                                         "full", "cross"]
                                            },
                                            "joinObjectName":  {"type": "string"},
                                            "sourceName":      {"type": "array"},
                                            "joinCriteria":    {"type": "string"},
                                            "filterCriteria":  {"type": "string"},
                                            "returnAttributes":{"type": "array"},
                                        }
                                    }
                                }
                            }
                        },
                        "dataFilteringRef": {
                            "type": "object",
                            "properties": {
                                "isActive": {"type": "boolean"},
                                "filters": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["id", "sourceName", "filterCriteria"],
                                        "properties": {
                                            "id":             {"type": "integer"},
                                            "filterName":     {"type": "string"},
                                            "sourceName":     {"type": "string"},
                                            "filterCriteria": {"type": "string"},
                                        }
                                    }
                                }
                            }
                        },
                        "calculatedColumnsRef": {
                            "type": "object",
                            "properties": {
                                "isActive": {"type": "boolean"},
                                "columns": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["id", "columnName", "expression"],
                                        "properties": {
                                            "id":             {"type": "integer"},
                                            "columnCategory": {
                                                "type": "string",
                                                "enum": ["New", "Replace"]
                                            },
                                            "columnName":  {"type": "string"},
                                            "sourceName":  {"type": "string"},
                                            "dataType":    {"type": "string"},
                                            "expression":  {"type": "string"},
                                        }
                                    }
                                }
                            }
                        },
                        "lookupRef": {
                            "type": "object",
                            "properties": {
                                "isActive": {"type": "boolean"},
                                "lookups":  {"type": "array"},
                            }
                        },
                        "executionSequence": {
                            "type": "array",
                            "items": {"type": "object"}
                        }
                    }
                },

                # ── dataLoadRef ───────────────────────────────────────────────
                "dataLoadRef": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "required": ["dataLoadTableName", "dataLoadType"],
                        "properties": {
                            "dataLoadTableName":   {"type": "string"},
                            "dataLoadType": {
                                "type": "string",
                                "enum": ["File", "Delta", "Database"]
                            },
                            "dataLoadFileType": {
                                "type": "string",
                                "enum": ["csv", "parquet", "json", "dat"]
                            },
                            "dataLoadFolder":      {"type": "string"},
                            "dataMappingTableName":{"type": "string"},
                            "dataSourceName":      {"type": "string"},
                            "writeMode": {
                                "type": "string",
                                "enum": ["append", "overwrite", "merge"]
                            },
                        }
                    }
                },

                # ── dataMappingRef ────────────────────────────────────────────
                "dataMappingRef": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["targetTableName", "attributes"],
                        "properties": {
                            "targetTableName": {"type": "string"},
                            "attributes": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "required": ["sourceAttributeName",
                                                 "targetAttributeName"],
                                    "properties": {
                                        "sourceAttributeName": {"type": "string"},
                                        "targetAttributeName": {"type": "string"},
                                    }
                                }
                            }
                        }
                    }
                },

                # ── dataFlowExecutionSequence ──────────────────────────────────
                "dataFlowExecutionSequence": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "string",
                        "enum": ["DataExtraction", "DataValidation",
                                 "DataTransformation", "DataLoad"]
                    }
                },
            }
        }
    }
}


class YAMLValidator:
    """Validates a pipeline YAML file against the MDDI schema."""

    VALID_STEPS = {
        "DataExtraction", "DataValidation",
        "DataTransformation", "DataLoad"
    }

    def validate(self, yaml_path: str) -> List[str]:
        """
        Validate a YAML file. Returns list of error strings (empty = valid).
        """
        errors: List[str] = []

        # Parse YAML
        try:
            with open(yaml_path, "r") as f:
                config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            return [f"YAML parse error: {e}"]
        except FileNotFoundError:
            return [f"File not found: {yaml_path}"]

        # JSON Schema validation
        validator = jsonschema.Draft7Validator(MDDI_PIPELINE_SCHEMA)
        for error in sorted(validator.iter_errors(config), key=lambda e: list(e.path)):
            path = " → ".join(str(p) for p in error.path) or "root"
            errors.append(f"[{path}] {error.message}")

        # Business rule: DataExtraction must come before DataLoad
        meta = config.get("metadataConfig", {})
        seq  = meta.get("dataFlowExecutionSequence", [])
        if seq:
            if "DataExtraction" not in seq:
                errors.append(
                    "[dataFlowExecutionSequence] 'DataExtraction' is required "
                    "in every pipeline."
                )
            if "DataLoad" not in seq:
                errors.append(
                    "[dataFlowExecutionSequence] 'DataLoad' is required "
                    "in every pipeline."
                )
            if ("DataTransformation" in seq and
                    seq.index("DataTransformation") < seq.index("DataExtraction")):
                errors.append(
                    "[dataFlowExecutionSequence] 'DataTransformation' must come "
                    "after 'DataExtraction'."
                )

        if errors:
            logger.error(f"[Validator] {len(errors)} error(s) in {yaml_path}")
            for e in errors:
                logger.error(f"  ✗ {e}")
        else:
            logger.info(f"[Validator] ✓ {yaml_path} is valid")

        return errors


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MDDI YAML Validator")
    parser.add_argument("--file", required=True, help="Path to pipeline YAML")
    args = parser.parse_args()
    errors = YAMLValidator().validate(args.file)
    exit(1 if errors else 0)
