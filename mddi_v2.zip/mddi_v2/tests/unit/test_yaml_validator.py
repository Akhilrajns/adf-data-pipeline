# tests/unit/test_yaml_validator.py
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import pytest
import yaml
import tempfile


VALID_YAML = {
    "metadataConfig": {
        "label": "TC_E2E_002_Full_Pipeline",
        "isActive": True,
        "isAuditEnabled": True,
        "dataExtractionRef": [
            {"dataSourceType": "File", "dataSourceName": "COUNTRY.csv",
             "sqlQueryRef": {"isActive": False}},
        ],
        "dataValidationRef": {"isActive": True, "rules": []},
        "dataTransformationRef": {},
        "dataLoadRef": [{"dataLoadTableName": "OUTPUT", "dataLoadType": "File",
                         "dataLoadFileType": "csv"}],
        "dataMappingRef": [],
        "dataFlowExecutionSequence": ["DataExtraction", "DataLoad"],
    }
}


def write_yaml(data):
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False)
    yaml.dump(data, tmp)
    tmp.close()
    return tmp.name


class TestYAMLValidator:

    def test_valid_yaml_returns_no_errors(self):
        from validators.yaml_validator import YAMLValidator
        errors = YAMLValidator().validate(write_yaml(VALID_YAML))
        assert errors == []

    def test_missing_extraction_ref_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        bad = dict(VALID_YAML)
        bad["metadataConfig"] = dict(VALID_YAML["metadataConfig"])
        bad["metadataConfig"]["dataExtractionRef"] = []
        errors = YAMLValidator().validate(write_yaml(bad))
        assert len(errors) > 0

    def test_invalid_sequence_step_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        bad = dict(VALID_YAML)
        bad["metadataConfig"] = dict(VALID_YAML["metadataConfig"])
        bad["metadataConfig"]["dataFlowExecutionSequence"] = [
            "DataExtraction", "InvalidStep", "DataLoad"
        ]
        errors = YAMLValidator().validate(write_yaml(bad))
        assert len(errors) > 0

    def test_missing_data_extraction_in_sequence(self):
        from validators.yaml_validator import YAMLValidator
        bad = dict(VALID_YAML)
        bad["metadataConfig"] = dict(VALID_YAML["metadataConfig"])
        bad["metadataConfig"]["dataFlowExecutionSequence"] = ["DataLoad"]
        errors = YAMLValidator().validate(write_yaml(bad))
        assert any("DataExtraction" in e for e in errors)

    def test_invalid_check_type_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        bad = dict(VALID_YAML)
        bad["metadataConfig"] = dict(VALID_YAML["metadataConfig"])
        bad["metadataConfig"]["dataValidationRef"] = {
            "isActive": True,
            "rules": [{"sourceName": "X", "checkType": "INVALID_CHECK",
                       "column": "ID", "severity": "ERROR"}]
        }
        errors = YAMLValidator().validate(write_yaml(bad))
        assert len(errors) > 0

    def test_file_not_found_returns_error(self):
        from validators.yaml_validator import YAMLValidator
        errors = YAMLValidator().validate("/nonexistent/path.yml")
        assert len(errors) > 0
