# tests/unit/test_data_validation.py
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import pytest
import yaml
from unittest.mock import MagicMock


SAMPLE_YAML = {
    "metadataConfig": {
        "label": "VALIDATION_TEST",
        "isActive": True,
        "isAuditEnabled": False,
        "dataExtractionRef": [
            {"dataSourceType": "File", "dataSourceName": "COUNTRY.csv",
             "sqlQueryRef": {"isActive": False}}
        ],
        "sourceMetadataRef": [],
        "targetMetadataRef": [],
        "dataValidationRef": {
            "isActive": True,
            "rules": [
                {"sourceName": "COUNTRY", "checkType": "NOT_NULL",
                 "column": "COUNTRYID", "severity": "ERROR"},
                {"sourceName": "COUNTRY", "checkType": "UNIQUE",
                 "column": "COUNTRYID", "severity": "ERROR"},
                {"sourceName": "COUNTRY", "checkType": "ROW_COUNT",
                 "column": "", "minRows": 1, "severity": "ERROR"},
            ]
        },
        "dataTransformationRef": {},
        "dataLoadRef": [{"dataLoadTableName": "OUT", "dataLoadType": "File",
                         "dataLoadFileType": "csv"}],
        "dataMappingRef": [],
        "dataFlowExecutionSequence": ["DataExtraction", "DataValidation", "DataLoad"],
    }
}


@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("MDDI_Validation_Tests")
        .config("spark.sql.shuffle.partitions", "1")
        .getOrCreate()
    )


@pytest.fixture
def config(tmp_path):
    from utils.config_loader import PipelineConfig
    p = tmp_path / "val.yml"
    p.write_text(yaml.dump(SAMPLE_YAML))
    return PipelineConfig(str(p))


@pytest.fixture
def metrics():
    from monitoring.metrics import PipelineMetrics
    return PipelineMetrics(pipeline_name="VALIDATION_TEST", run_id="r1")


class TestDataValidationStep:

    def test_skips_when_inactive(self, spark, tmp_path, metrics):
        from utils.config_loader import PipelineConfig
        from steps.data_validation import DataValidationStep
        inactive = dict(SAMPLE_YAML)
        inactive["metadataConfig"] = dict(SAMPLE_YAML["metadataConfig"])
        inactive["metadataConfig"]["dataValidationRef"] = {"isActive": False, "rules": []}
        p = tmp_path / "inactive.yml"
        p.write_text(yaml.dump(inactive))
        cfg = PipelineConfig(str(p))
        step = DataValidationStep(spark=spark, config=cfg, metrics=metrics)
        df = spark.createDataFrame([(1, "USA")], ["COUNTRYID", "COUNTRYNAME"])
        sources = {"COUNTRY": df}
        result = step.execute(sources)
        # Should return unchanged
        assert result["COUNTRY"].count() == 1

    def test_not_null_removes_null_rows(self, spark, config, metrics):
        from steps.data_validation import DataValidationStep
        step = DataValidationStep(spark=spark, config=config, metrics=metrics)
        df = spark.createDataFrame(
            [(1, "USA"), (None, "UK"), (3, "DE")],
            ["COUNTRYID", "COUNTRYNAME"]
        )
        df.createOrReplaceTempView("COUNTRY")
        clean, quarantine = step._validate_source(df, "COUNTRY", [
            {"checkType": "NOT_NULL", "column": "COUNTRYID", "severity": "WARN"}
        ])
        assert clean.count() == 2
        assert quarantine.count() == 1

    def test_row_count_raises_on_error_severity(self, spark, config, metrics):
        from steps.data_validation import DataValidationStep
        step = DataValidationStep(spark=spark, config=config, metrics=metrics)
        empty_df = spark.createDataFrame([], spark.createDataFrame([(1,)], ["ID"]).schema)
        with pytest.raises(ValueError, match="ROW_COUNT"):
            step._validate_source(empty_df, "COUNTRY", [
                {"checkType": "ROW_COUNT", "column": "", "minRows": 1, "severity": "ERROR"}
            ])
