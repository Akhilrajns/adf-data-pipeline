# tests/unit/test_data_transformation.py
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import pytest
import yaml


TRANSFORM_YAML = {
    "metadataConfig": {
        "label": "TRANSFORM_TEST",
        "isActive": True,
        "isAuditEnabled": False,
        "dataExtractionRef": [
            {"dataSourceType": "File", "dataSourceName": "COUNTRY.csv",
             "sqlQueryRef": {"isActive": False}},
            {"dataSourceType": "File", "dataSourceName": "REGION.csv",
             "sqlQueryRef": {"isActive": False}},
        ],
        "sourceMetadataRef": [],
        "targetMetadataRef": [],
        "dataValidationRef": {"isActive": False, "rules": []},
        "dataTransformationRef": {
            "dataJoinRef": {
                "isActive": True,
                "joins": [{
                    "id": 1, "joinType": "left",
                    "joinObjectName": "JOIN_RESULT",
                    "sourceName": ["COUNTRY", "REGION"],
                    "joinCriteria": "REGIONID = REGIONID",
                    "filterCriteria": "",
                    "returnAttributes": ["COUNTRYNAME", "CONTINENT", "HEMISPHERE"]
                }]
            },
            "dataFilteringRef": {
                "isActive": True,
                "filters": [{
                    "id": 1, "filterName": "NORTHERN",
                    "sourceName": "JOIN_RESULT",
                    "filterCriteria": "HEMISPHERE = 'Northern'"
                }]
            },
            "calculatedColumnsRef": {
                "isActive": True,
                "columns": [{
                    "id": 1, "columnCategory": "New",
                    "columnName": "COUNTRY_INFO",
                    "sourceName": "NORTHERN",
                    "dataType": "string",
                    "expression": "CONCAT(COUNTRYNAME, ' - ', CONTINENT)"
                }]
            },
            "lookupRef": {"isActive": False, "lookups": []},
            "executionSequence": [
                {"DataJoin": {"join": [1]}},
                {"DataFiltering": {"filter": [1]}},
                {"CalculatedColumns": {"calculation": [1]}},
            ]
        },
        "dataLoadRef": [{"dataLoadTableName": "OUT", "dataLoadType": "File",
                         "dataLoadFileType": "csv"}],
        "dataMappingRef": [],
        "dataFlowExecutionSequence": ["DataExtraction", "DataTransformation", "DataLoad"],
    }
}


@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("MDDI_Transform_Tests")
        .config("spark.sql.shuffle.partitions", "1")
        .getOrCreate()
    )


@pytest.fixture
def config(tmp_path):
    from utils.config_loader import PipelineConfig
    p = tmp_path / "transform.yml"
    p.write_text(yaml.dump(TRANSFORM_YAML))
    return PipelineConfig(str(p))


class TestDataTransformationStep:

    def test_join_produces_correct_rows(self, spark, config):
        from steps.data_transformation import DataTransformationStep

        country_df = spark.createDataFrame([
            (1, "USA",    1), (2, "UK",     2),
            (3, "Canada", 1), (4, "Brazil", 3),
        ], ["COUNTRYID", "COUNTRYNAME", "REGIONID"])

        region_df = spark.createDataFrame([
            (1, "North America", "Northern"),
            (2, "Europe",        "Northern"),
            (3, "South America", "Southern"),
        ], ["REGIONID", "CONTINENT", "HEMISPHERE"])

        country_df.createOrReplaceTempView("COUNTRY")
        region_df.createOrReplaceTempView("REGION")

        step = DataTransformationStep(spark=spark, config=config)
        sources = {"COUNTRY": country_df, "REGION": region_df}
        result = step.execute(sources)

        # After join + HEMISPHERE='Northern' filter → USA, UK, Canada
        assert result.count() == 3
        assert "COUNTRY_INFO" in result.columns

    def test_calculated_column_expression(self, spark, config):
        from steps.data_transformation import DataTransformationStep
        from pyspark.sql import functions as F

        df = spark.createDataFrame([
            ("USA", "North America", "Northern"),
            ("UK",  "Europe",        "Northern"),
        ], ["COUNTRYNAME", "CONTINENT", "HEMISPHERE"])

        df.createOrReplaceTempView("NORTHERN")

        step = DataTransformationStep(spark=spark, config=config)
        transform_ref = config.data_transformation_ref
        result = step._handle_calculated_columns(
            df, transform_ref, {"calculation": [1]}
        )
        info_vals = [r["COUNTRY_INFO"] for r in result.collect()]
        assert "USA - North America" in info_vals

    def test_filter_northern_hemisphere(self, spark, config):
        from steps.data_transformation import DataTransformationStep

        df = spark.createDataFrame([
            ("USA",    "North America", "Northern"),
            ("Brazil", "South America", "Southern"),
            ("UK",     "Europe",        "Northern"),
        ], ["COUNTRYNAME", "CONTINENT", "HEMISPHERE"])
        df.createOrReplaceTempView("JOIN_RESULT")

        step = DataTransformationStep(spark=spark, config=config)
        result = step._handle_data_filtering(
            df, config.data_transformation_ref, {"filter": [1]}
        )
        assert result.count() == 2
        hemispheres = [r["HEMISPHERE"] for r in result.collect()]
        assert all(h == "Northern" for h in hemispheres)
