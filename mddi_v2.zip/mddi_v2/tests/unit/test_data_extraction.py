# tests/unit/test_data_extraction.py
# Unit tests for DataExtractionStep
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import pytest
from unittest.mock import MagicMock, patch, mock_open
import yaml


SAMPLE_YAML = {
    "metadataConfig": {
        "label": "TEST_PIPELINE",
        "isActive": True,
        "isAuditEnabled": False,
        "dataExtractionRef": [
            {"dataSourceType": "File", "dataSourceFilePath": "", "dataSourceName": "COUNTRY.csv",
             "sqlQueryRef": {"isActive": False}},
            {"dataSourceType": "File", "dataSourceFilePath": "", "dataSourceName": "REGION.csv",
             "sqlQueryRef": {"isActive": False}},
        ],
        "sourceMetadataRef": [
            {"name": "COUNTRY", "attributes": [
                {"attributeName": "COUNTRYID", "attributeType": "integer"},
                {"attributeName": "COUNTRYNAME", "attributeType": "string", "attributeLength": 50},
            ]},
        ],
        "targetMetadataRef": [],
        "dataValidationRef": {"isActive": False, "rules": []},
        "dataTransformationRef": {},
        "dataLoadRef": [{"dataLoadTableName": "OUT", "dataLoadType": "File",
                         "dataLoadFileType": "csv", "dataLoadFolder": ""}],
        "dataMappingRef": [],
        "dataFlowExecutionSequence": ["DataExtraction", "DataLoad"],
    }
}


@pytest.fixture
def config(tmp_path):
    from utils.config_loader import PipelineConfig
    p = tmp_path / "pipeline.yml"
    p.write_text(yaml.dump(SAMPLE_YAML))
    return PipelineConfig(str(p))


@pytest.fixture
def mock_metrics():
    from monitoring.metrics import PipelineMetrics
    return PipelineMetrics(pipeline_name="TEST", run_id="test-001")


class TestDataExtractionStep:

    def test_raises_if_extraction_ref_empty(self, tmp_path):
        from utils.config_loader import PipelineConfig
        from monitoring.metrics import PipelineMetrics
        from steps.data_extraction import DataExtractionStep

        empty_yaml = dict(SAMPLE_YAML)
        empty_yaml["metadataConfig"] = dict(SAMPLE_YAML["metadataConfig"])
        empty_yaml["metadataConfig"]["dataExtractionRef"] = []
        p = tmp_path / "empty.yml"
        p.write_text(yaml.dump(empty_yaml))
        cfg = PipelineConfig(str(p))
        metrics = PipelineMetrics(pipeline_name="T", run_id="r1")
        spark = MagicMock()
        step = DataExtractionStep(spark=spark, config=cfg, metrics=metrics)
        with pytest.raises(ValueError, match="dataExtractionRef is empty"):
            step.execute()

    def test_resolves_logical_name_from_filename(self):
        from steps.data_extraction import DataExtractionStep
        step = DataExtractionStep.__new__(DataExtractionStep)
        # "COUNTRY.csv" → "COUNTRY"
        assert "COUNTRY.csv".rsplit(".", 1)[0].upper() == "COUNTRY"
        assert "REGION.csv".rsplit(".", 1)[0].upper() == "REGION"

    def test_file_format_inferred_from_extension(self):
        from steps.data_extraction import _EXT_FORMAT
        assert _EXT_FORMAT["csv"] == "csv"
        assert _EXT_FORMAT["parquet"] == "parquet"
        assert _EXT_FORMAT["dat"] == "csv"
        assert _EXT_FORMAT["json"] == "json"
