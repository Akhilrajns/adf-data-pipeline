# steps/data_load.py
# ─────────────────────────────────────────────
# MDDI — DataLoad Step
#
# Reads dataLoadRef and writes each target.
# Before writing, applies dataMappingRef column renames
# and projects only the columns defined in targetMetadataRef.
#
# Supported load types (from YAML dataLoadType):
#   File     → writes CSV / Parquet / JSON / DAT to dataLoadFolder
#   Delta    → writes to a Delta Lake table
#   Database → writes via JDBC connector
#
# YAML shape:
#   dataLoadRef:
#     - dataLoadTableName:   FULL_PIPELINE_OUTPUT
#       dataLoadType:        File
#       dataLoadFileType:    csv
#       dataLoadFolder:      ""
#       dataMappingTableName: FULL_PIPELINE_OUTPUT
#       dataSourceName:      NORTHERN     ← temp view to read from
# ─────────────────────────────────────────────

import os
from typing import Dict, List, Optional
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics
from utils.config_loader import PipelineConfig

logger = MDDILogger.get_logger(__name__)

# Spark write format per file type
_FILE_FORMAT = {
    "csv":     "csv",
    "json":    "json",
    "parquet": "parquet",
    "dat":     "csv",
}

# Default write options per format
_WRITE_OPTIONS = {
    "csv": {"header": "true", "sep": ","},
    "dat": {"header": "false", "sep": "|"},
    "json": {},
    "parquet": {},
}


class DataLoadStep:
    """
    Executes the DataLoad step.

    For each entry in dataLoadRef:
      1. Reads the source view (dataSourceName) or the passed-in DataFrame
      2. Applies column mapping from dataMappingRef
      3. Projects columns to match targetMetadataRef attribute order
      4. Writes to the configured target (File / Delta / Database)
    """

    def __init__(self, spark: SparkSession, config: PipelineConfig,
                 metrics: PipelineMetrics):
        self.spark   = spark
        self.config  = config
        self.metrics = metrics

    def execute(self, df: DataFrame) -> None:
        """
        Write to all targets defined in dataLoadRef.

        Args:
            df: Final transformed DataFrame from the previous step.
        """
        load_refs: List[dict] = self.config.data_load_ref

        if not load_refs:
            raise ValueError(
                "[DataLoad] dataLoadRef is empty — "
                "no load targets defined in the pipeline YAML."
            )

        for load_ref in load_refs:
            table_name   = load_ref.get("dataLoadTableName", "output")
            load_type    = load_ref.get("dataLoadType", "File").lower()
            file_type    = load_ref.get("dataLoadFileType", "csv").lower()
            folder       = load_ref.get("dataLoadFolder", "")
            mapping_name = load_ref.get("dataMappingTableName", table_name)
            source_view  = load_ref.get("dataSourceName", "")
            write_mode   = load_ref.get("writeMode", "overwrite").lower()

            logger.info(
                f"[DataLoad] Target: {table_name} | "
                f"type={load_type} | format={file_type} | "
                f"source_view={source_view}"
            )

            # 1. Resolve source DataFrame
            source_df = self._resolve_source(df, source_view)

            # 2. Apply dataMappingRef column renames
            mapped_df = self._apply_mapping(source_df, mapping_name)

            # 3. Project to target schema column order
            projected_df = self._project_to_target_schema(mapped_df, table_name)

            # 4. Write
            if load_type == "file":
                self._write_file(projected_df, table_name, file_type, folder, write_mode)
            elif load_type == "delta":
                self._write_delta(projected_df, table_name, write_mode, load_ref)
            elif load_type == "database":
                self._write_database(projected_df, load_ref)
            else:
                raise ValueError(
                    f"[DataLoad] Unknown dataLoadType: '{load_type}'. "
                    "Supported: File, Delta, Database."
                )

            self.metrics.target_row_count += projected_df.count()
            logger.info(
                f"[DataLoad] ✓ {table_name} written | "
                f"rows={projected_df.count()}"
            )

    # ── Source resolution ─────────────────────────────────────────────────────

    def _resolve_source(self, df: DataFrame, source_view: str) -> DataFrame:
        """
        If dataSourceName references a registered temp view, load it.
        Otherwise fall through to the passed-in DataFrame.
        """
        if source_view:
            try:
                loaded = self.spark.table(source_view)
                logger.info(f"[DataLoad] Loading from temp view: {source_view}")
                return loaded
            except Exception:
                logger.info(
                    f"[DataLoad] Temp view '{source_view}' not found — "
                    "using transformed DataFrame"
                )
        return df

    # ── Mapping ───────────────────────────────────────────────────────────────

    def _apply_mapping(self, df: DataFrame, mapping_table_name: str) -> DataFrame:
        """
        Rename columns per dataMappingRef for the given target table.
        Only renames where sourceAttributeName != targetAttributeName.
        """
        mappings = self.config.get_mapping(mapping_table_name)
        if not mappings:
            logger.info(
                f"[DataLoad] No dataMappingRef found for '{mapping_table_name}' — "
                "using columns as-is"
            )
            return df

        for attr in mappings:
            src = attr.get("sourceAttributeName")
            tgt = attr.get("targetAttributeName")
            if src and tgt and src != tgt and src in df.columns:
                df = df.withColumnRenamed(src, tgt)
                logger.info(f"[DataLoad] Mapped: {src} → {tgt}")

        return df

    # ── Target schema projection ──────────────────────────────────────────────

    def _project_to_target_schema(self, df: DataFrame,
                                  target_name: str) -> DataFrame:
        """
        Select and order columns to match targetMetadataRef for the given table.
        Columns not present in the DataFrame are added as NULL with correct type.
        """
        target_schema = self.config.get_target_schema(target_name)
        if not target_schema:
            logger.info(
                f"[DataLoad] No targetMetadataRef for '{target_name}' — "
                "writing all columns"
            )
            return df

        from utils.schema_builder import build_spark_schema
        attributes = sorted(
            target_schema.get("attributes", []),
            key=lambda a: a.get("attributePosition", 99)
        )
        target_cols = [a["attributeName"] for a in attributes]
        spark_schema = build_spark_schema(attributes)

        select_exprs = []
        for field in spark_schema.fields:
            col_name = field.name
            if col_name in df.columns:
                select_exprs.append(F.col(col_name).cast(field.dataType).alias(col_name))
            else:
                select_exprs.append(F.lit(None).cast(field.dataType).alias(col_name))
                logger.warning(
                    f"[DataLoad] Target column '{col_name}' not in DataFrame — "
                    "writing NULL"
                )

        return df.select(*select_exprs)

    # ── Writers ───────────────────────────────────────────────────────────────

    def _write_file(self, df: DataFrame, table_name: str, file_type: str,
                    folder: str, mode: str) -> None:
        """Write DataFrame to a file (CSV / Parquet / JSON / DAT)."""
        fmt     = _FILE_FORMAT.get(file_type, "csv")
        options = _WRITE_OPTIONS.get(file_type, {})
        path    = os.path.join(folder, table_name) if folder else table_name

        logger.info(f"[DataLoad] Writing file: {path} (format={fmt}, mode={mode})")
        df.write.format(fmt).options(**options).mode(mode).save(path)

    def _write_delta(self, df: DataFrame, table_name: str,
                     mode: str, load_ref: dict) -> None:
        """Write DataFrame to a Delta Lake table, with optional MERGE support."""
        database    = load_ref.get("database", "main")
        schema_name = load_ref.get("schema", "default")
        full_table  = f"{database}.{schema_name}.{table_name}"
        merge_keys  = load_ref.get("mergeKeys", [])

        if mode == "merge" and merge_keys:
            self._delta_merge(df, full_table, merge_keys)
        else:
            logger.info(
                f"[DataLoad] Writing Delta table: {full_table} (mode={mode})"
            )
            df.write.format("delta").mode(mode) \
                .option("mergeSchema", "true").saveAsTable(full_table)

    def _delta_merge(self, df: DataFrame, full_table: str,
                     merge_keys: List[str]) -> None:
        """Perform a Delta Lake MERGE (upsert)."""
        from delta.tables import DeltaTable
        join_cond  = " AND ".join(
            f"target.{k} = source.{k}" for k in merge_keys
        )
        update_set = {c: f"source.{c}" for c in df.columns}

        if DeltaTable.isDeltaTable(self.spark, full_table):
            delta_tbl = DeltaTable.forName(self.spark, full_table)
            (
                delta_tbl.alias("target")
                .merge(df.alias("source"), join_cond)
                .whenMatchedUpdate(set=update_set)
                .whenNotMatchedInsert(values={c: f"source.{c}" for c in df.columns})
                .execute()
            )
            logger.info(f"[DataLoad] Delta MERGE complete: {full_table}")
        else:
            df.write.format("delta").mode("overwrite") \
                .saveAsTable(full_table)
            logger.info(
                f"[DataLoad] Table not found — created via overwrite: {full_table}"
            )

    def _write_database(self, df: DataFrame, load_ref: dict) -> None:
        """Write to a JDBC database target."""
        conn_ref = load_ref.get("connection_ref", "")
        if not conn_ref:
            raise ValueError(
                "[DataLoad] dataLoadType=Database requires 'connection_ref'."
            )
        from connectors.connector_factory import ConnectorFactory
        from utils.connections import load_connections
        conn_config = load_connections().get(conn_ref, {})
        connector = ConnectorFactory.get_connector(
            conn_config.get("type"), conn_config, self.spark
        )
        connector.write(
            df=df,
            table=load_ref.get("dataLoadTableName"),
            schema=load_ref.get("schema"),
            mode=load_ref.get("writeMode", "append"),
        )
