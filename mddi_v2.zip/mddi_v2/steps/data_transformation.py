# steps/data_transformation.py
# ─────────────────────────────────────────────
# MDDI — DataTransformation Step
#
# Reads dataTransformationRef and executes sub-steps in the
# order defined by executionSequence.
#
# Sub-steps (all optional):
#   DataJoin          → joins two or more source temp views
#   DataFiltering     → filters rows from a named view
#   CalculatedColumns → adds new derived columns
#   Lookup            → enriches data from a lookup source (when isActive=true)
#
# Each sub-step registers its result as a new temp view
# (joinObjectName / filterName / sourceName) so subsequent
# sub-steps can reference it by name.
#
# Returns: the final transformed DataFrame
# ─────────────────────────────────────────────

from typing import Dict, List, Optional
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from monitoring.logger import MDDILogger
from utils.config_loader import PipelineConfig

logger = MDDILogger.get_logger(__name__)


class DataTransformationStep:
    """
    Executes all sub-steps inside dataTransformationRef
    in the order specified by executionSequence.
    """

    # Maps YAML executionSequence key → handler method name
    _HANDLER_MAP = {
        "DataJoin":         "_handle_data_join",
        "DataFiltering":    "_handle_data_filtering",
        "CalculatedColumns": "_handle_calculated_columns",
        "Lookup":           "_handle_lookup",
    }

    def __init__(self, spark: SparkSession, config: PipelineConfig):
        self.spark  = spark
        self.config = config

    def execute(self, sources: Dict[str, DataFrame]) -> DataFrame:
        """
        Execute all transformation sub-steps in executionSequence order.

        Args:
            sources: { source_name: DataFrame } from previous step.

        Returns:
            Final transformed DataFrame (last view produced by the sequence).
        """
        transform_ref = self.config.data_transformation_ref

        if not transform_ref:
            logger.info("[DataTransformation] No dataTransformationRef defined — skipped")
            # Return the first available source as-is
            return next(iter(sources.values()))

        sequence: List[dict] = transform_ref.get("executionSequence", [])
        if not sequence:
            logger.info(
                "[DataTransformation] executionSequence is empty — "
                "returning first source unchanged"
            )
            return next(iter(sources.values()))

        logger.info(
            f"[DataTransformation] Executing {len(sequence)} sub-step(s): "
            + " → ".join(list(step.keys())[0] for step in sequence)
        )

        current_df = next(iter(sources.values()))

        for step_block in sequence:
            # Each block is: { "DataJoin": {"join": [1]} }
            for step_name, step_config in step_block.items():
                handler_name = self._HANDLER_MAP.get(step_name)
                if not handler_name:
                    logger.warning(
                        f"[DataTransformation] Unknown sub-step '{step_name}' — skipping"
                    )
                    continue

                logger.info(f"[DataTransformation] ▶ {step_name} | config={step_config}")
                handler = getattr(self, handler_name)
                current_df = handler(current_df, transform_ref, step_config)

        return current_df

    # ─────────────────────────────────────────────────────────────────────────
    # DataJoin
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_data_join(self, df: DataFrame, transform_ref: dict,
                          step_config: dict) -> DataFrame:
        """
        Reads dataJoinRef.joins for the IDs listed in step_config["join"].
        Joins the specified source temp views and registers the result.

        YAML shape:
          dataJoinRef:
            isActive: true
            joins:
              - id: 1
                joinType: left
                joinObjectName: JOIN_RESULT
                sourceName: ["COUNTRY", "REGION"]
                joinCriteria: REGIONID = REGIONID
                filterCriteria: ""
                returnAttributes: [COUNTRYNAME, COUNTRYNAMEABBREVIATION, CONTINENT, HEMISPHERE]
        """
        join_ref = transform_ref.get("dataJoinRef", {})
        if not join_ref.get("isActive", False):
            logger.info("[DataJoin] isActive=false — skipped")
            return df

        all_joins: Dict[int, dict] = {
            j["id"]: j for j in join_ref.get("joins", [])
        }
        join_ids: List[int] = step_config.get("join", [])

        for jid in join_ids:
            join_def = all_joins.get(jid)
            if not join_def:
                logger.warning(f"[DataJoin] Join id={jid} not found in dataJoinRef — skipping")
                continue

            join_type        = join_def.get("joinType", "inner").lower()
            output_view_name = join_def.get("joinObjectName", f"JOIN_{jid}")
            source_names     = join_def.get("sourceName", [])
            join_criteria    = join_def.get("joinCriteria", "")
            filter_criteria  = join_def.get("filterCriteria", "")
            return_attrs     = join_def.get("returnAttributes", [])

            logger.info(
                f"[DataJoin] id={jid} | type={join_type} | "
                f"sources={source_names} | output={output_view_name}"
            )

            if len(source_names) < 2:
                logger.warning(
                    f"[DataJoin] id={jid} requires at least 2 sources — skipping"
                )
                continue

            # Load each source from registered temp views
            left_name  = source_names[0].upper()
            right_name = source_names[1].upper()

            left_df  = self._load_view(left_name)
            right_df = self._load_view(right_name)

            # Build join condition from "COL1 = COL2"
            result_df = self._apply_join(
                left_df, right_df, join_criteria, join_type,
                left_name, right_name
            )

            # Optional post-join filter
            if filter_criteria:
                result_df = result_df.filter(F.expr(filter_criteria))
                logger.info(f"[DataJoin] Post-join filter: {filter_criteria}")

            # Project only returnAttributes (if specified)
            if return_attrs:
                available = [c for c in return_attrs if c in result_df.columns]
                missing   = [c for c in return_attrs if c not in result_df.columns]
                if missing:
                    logger.warning(
                        f"[DataJoin] returnAttributes not found in join result: {missing}"
                    )
                result_df = result_df.select(*available)

            # Register result so next sub-step can reference it
            result_df.createOrReplaceTempView(output_view_name)
            logger.info(
                f"[DataJoin] Registered view: {output_view_name} | "
                f"rows={result_df.count()} | cols={result_df.columns}"
            )
            df = result_df

        return df

    def _apply_join(self, left: DataFrame, right: DataFrame,
                    criteria: str, join_type: str,
                    left_name: str, right_name: str) -> DataFrame:
        """
        Parse "LEFT_COL = RIGHT_COL" join criteria and execute the join.
        Handles ambiguous column names by aliasing DataFrames.
        """
        left_aliased  = left.alias(left_name)
        right_aliased = right.alias(right_name)

        if "=" in criteria:
            parts     = [p.strip() for p in criteria.split("=")]
            left_col  = parts[0]
            right_col = parts[1]

            join_condition = (
                F.col(f"{left_name}.{left_col}") ==
                F.col(f"{right_name}.{right_col}")
            )
            joined = left_aliased.join(right_aliased, join_condition, how=join_type)

            # Drop duplicate join key from right side
            if left_col == right_col:
                joined = joined.drop(right_aliased[right_col])
        else:
            # Fallback: natural join — Spark handles column name matching
            joined = left_aliased.join(right_aliased, how=join_type)

        return joined

    # ─────────────────────────────────────────────────────────────────────────
    # DataFiltering
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_data_filtering(self, df: DataFrame, transform_ref: dict,
                               step_config: dict) -> DataFrame:
        """
        Reads dataFilteringRef.filters for the IDs listed in step_config["filter"].
        Applies WHERE condition and registers filtered result as a new view.

        YAML shape:
          dataFilteringRef:
            isActive: true
            filters:
              - id: 1
                filterName: NORTHERN
                sourceName: JOIN_RESULT
                filterCriteria: HEMISPHERE = 'Northern'
        """
        filter_ref = transform_ref.get("dataFilteringRef", {})
        if not filter_ref.get("isActive", False):
            logger.info("[DataFiltering] isActive=false — skipped")
            return df

        all_filters: Dict[int, dict] = {
            f["id"]: f for f in filter_ref.get("filters", [])
        }
        filter_ids: List[int] = step_config.get("filter", [])

        for fid in filter_ids:
            filter_def = all_filters.get(fid)
            if not filter_def:
                logger.warning(
                    f"[DataFiltering] Filter id={fid} not found — skipping"
                )
                continue

            output_view  = filter_def.get("filterName", f"FILTER_{fid}")
            source_view  = filter_def.get("sourceName", "")
            filter_crit  = filter_def.get("filterCriteria", "")

            logger.info(
                f"[DataFiltering] id={fid} | source={source_view} | "
                f"criteria={filter_crit} | output={output_view}"
            )

            # Load from the named source view
            source_df = self._load_view(source_view) if source_view else df

            before = source_df.count()
            result_df = source_df.filter(F.expr(filter_crit)) if filter_crit else source_df
            after  = result_df.count()

            logger.info(
                f"[DataFiltering] '{filter_crit}' | "
                f"{before} → {after} rows"
            )

            result_df.createOrReplaceTempView(output_view)
            logger.info(f"[DataFiltering] Registered view: {output_view}")
            df = result_df

        return df

    # ─────────────────────────────────────────────────────────────────────────
    # CalculatedColumns
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_calculated_columns(self, df: DataFrame, transform_ref: dict,
                                   step_config: dict) -> DataFrame:
        """
        Reads calculatedColumnsRef.columns for the IDs in step_config["calculation"].
        Adds derived columns via SQL expressions.

        YAML shape:
          calculatedColumnsRef:
            isActive: true
            columns:
              - id: 1
                columnCategory: New     # New | Replace
                columnName: COUNTRY_INFO
                sourceName: NORTHERN
                dataType: string
                expression: CONCAT(COUNTRYNAME, ' - ', CONTINENT)
        """
        calc_ref = transform_ref.get("calculatedColumnsRef", {})
        if not calc_ref.get("isActive", False):
            logger.info("[CalculatedColumns] isActive=false — skipped")
            return df

        all_cols: Dict[int, dict] = {
            c["id"]: c for c in calc_ref.get("columns", [])
        }
        calc_ids: List[int] = step_config.get("calculation", [])

        for cid in calc_ids:
            col_def = all_cols.get(cid)
            if not col_def:
                logger.warning(
                    f"[CalculatedColumns] Calculation id={cid} not found — skipping"
                )
                continue

            col_name    = col_def.get("columnName")
            expression  = col_def.get("expression")
            source_view = col_def.get("sourceName", "")
            category    = col_def.get("columnCategory", "New")

            logger.info(
                f"[CalculatedColumns] id={cid} | category={category} | "
                f"column={col_name} | expr={expression} | source={source_view}"
            )

            # Load from named source view if specified
            source_df = self._load_view(source_view) if source_view else df

            if col_name and expression:
                result_df = source_df.withColumn(col_name, F.expr(expression))
                logger.info(
                    f"[CalculatedColumns] Added column '{col_name}' "
                    f"= {expression}"
                )
                df = result_df

        return df

    # ─────────────────────────────────────────────────────────────────────────
    # Lookup (extension point)
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_lookup(self, df: DataFrame, transform_ref: dict,
                       step_config: dict) -> DataFrame:
        """
        Handles lookupRef.lookups.
        When isActive=true, enriches df with values from a lookup source.
        Currently a no-op when isActive=false (as in the sample YAML).

        YAML shape:
          lookupRef:
            isActive: false
            lookups: []
        """
        lookup_ref = transform_ref.get("lookupRef", {})
        if not lookup_ref.get("isActive", False):
            logger.info("[Lookup] isActive=false — skipped")
            return df

        # Extension point: implement lookup join logic per project need
        lookups = lookup_ref.get("lookups", [])
        logger.info(f"[Lookup] {len(lookups)} lookup(s) defined but not yet implemented")
        return df

    # ── Helper ────────────────────────────────────────────────────────────────

    def _load_view(self, view_name: str) -> DataFrame:
        """Load a DataFrame from a registered Spark temp view."""
        try:
            return self.spark.table(view_name)
        except Exception as e:
            raise ValueError(
                f"[DataTransformation] Could not load temp view '{view_name}'. "
                f"Ensure it was registered by a prior step. Error: {e}"
            )
