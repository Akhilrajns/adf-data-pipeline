# steps/data_validation.py
# ─────────────────────────────────────────────
# MDDI — DataValidation Step
#
# Reads dataValidationRef and applies each rule against
# the corresponding source temp view.
#
# Supported checkTypes (from YAML):
#   NOT_NULL    → column must not contain nulls
#   UNIQUE      → column values must be distinct
#   ROW_COUNT   → source must have at least minRows rows
#   REGEX       → column values must match regex_pattern
#   MIN_VALUE   → numeric column must be >= min_value
#   MAX_VALUE   → numeric column must be <= max_value
#
# severity:
#   ERROR → raises ValueError if check fails (pipeline halts)
#   WARN  → logs warning and continues
#
# Returns: Dict of { source_name: (clean_df, quarantine_df) }
# ─────────────────────────────────────────────

from typing import Dict, List, Optional, Tuple
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics
from utils.config_loader import PipelineConfig

logger = MDDILogger.get_logger(__name__)

# Maps YAML checkType → internal handler name
_CHECK_TYPE_MAP = {
    "NOT_NULL":  "not_null",
    "UNIQUE":    "unique",
    "REGEX":     "regex",
    "MIN_VALUE": "min_value",
    "MAX_VALUE": "max_value",
}


class DataValidationStep:
    """
    Executes the DataValidation step.

    For each source referenced in the validation rules:
      1. Loads the source from its registered temp view
      2. Applies all rules for that source
      3. Splits into clean and quarantine DataFrames
      4. Re-registers the clean view under the same name
      5. Persists quarantine rows to mddi.quarantine Delta table
    """

    def __init__(self, spark: SparkSession, config: PipelineConfig,
                 metrics: PipelineMetrics):
        self.spark   = spark
        self.config  = config
        self.metrics = metrics

    def execute(self, sources: Dict[str, DataFrame]) -> Dict[str, DataFrame]:
        """
        Run all validation rules.

        Args:
            sources: { source_name: DataFrame } from DataExtraction step.

        Returns:
            Updated { source_name: clean_DataFrame } — quarantine rows removed.
        """
        validation_ref = self.config.data_validation_ref

        if not validation_ref.get("isActive", False):
            logger.info("[DataValidation] isActive=false — step skipped")
            return sources

        rules: List[dict] = validation_ref.get("rules", [])
        if not rules:
            logger.info("[DataValidation] No rules defined — step skipped")
            return sources

        # Group rules by source name
        rules_by_source: Dict[str, List[dict]] = {}
        for rule in rules:
            src = rule.get("sourceName", "")
            rules_by_source.setdefault(src, []).append(rule)

        clean_sources = dict(sources)

        for source_name, source_rules in rules_by_source.items():
            df = sources.get(source_name)
            if df is None:
                logger.warning(
                    f"[DataValidation] Source '{source_name}' not found in "
                    "extracted sources — skipping its rules"
                )
                continue

            logger.info(
                f"[DataValidation] Validating '{source_name}' | "
                f"{len(source_rules)} rule(s)"
            )

            clean_df, quarantine_df = self._validate_source(
                df=df,
                source_name=source_name,
                rules=source_rules,
            )

            # Update metrics
            self.metrics.dq_pass_count     += clean_df.count()
            self.metrics.dq_fail_count      += quarantine_df.count() if quarantine_df else 0
            self.metrics.quarantine_row_count += quarantine_df.count() if quarantine_df else 0

            # Persist quarantine rows
            if quarantine_df and quarantine_df.count() > 0:
                self._save_quarantine(quarantine_df, source_name)

            # Re-register clean view so downstream steps see validated data
            clean_df.createOrReplaceTempView(source_name)
            clean_sources[source_name] = clean_df

        return clean_sources

    # ── Per-source validation ─────────────────────────────────────────────────

    def _validate_source(self, df: DataFrame, source_name: str,
                         rules: List[dict]) -> Tuple[DataFrame, Optional[DataFrame]]:
        """
        Apply all rules for one source.
        Returns (clean_df, quarantine_df).
        """
        fail_columns: List[F.Column] = []
        has_error_severity = False

        for rule in rules:
            check_type = rule.get("checkType", "")
            column     = rule.get("column", "")
            severity   = rule.get("severity", "ERROR")

            if severity == "ERROR":
                has_error_severity = True

            # ── ROW_COUNT: checked at source level, not column level ──────────
            if check_type == "ROW_COUNT":
                min_rows = rule.get("minRows", 1)
                actual   = df.count()
                msg = (
                    f"[DataValidation] ROW_COUNT | source={source_name} | "
                    f"minRows={min_rows} | actual={actual}"
                )
                if actual < min_rows:
                    if severity == "ERROR":
                        raise ValueError(
                            f"{msg} — FAILED (severity=ERROR)"
                        )
                    else:
                        logger.warning(f"{msg} — WARN (continuing)")
                else:
                    logger.info(f"{msg} — PASSED")
                continue

            # ── Column-level checks ───────────────────────────────────────────
            if not column:
                logger.warning(
                    f"[DataValidation] checkType={check_type} has no column — skipping"
                )
                continue

            internal_check = _CHECK_TYPE_MAP.get(check_type)
            if not internal_check:
                logger.warning(
                    f"[DataValidation] Unknown checkType '{check_type}' — skipping"
                )
                continue

            fail_expr = self._build_fail_expr(internal_check, column, rule, df)
            if fail_expr is not None:
                fail_columns.append(fail_expr)
                logger.info(
                    f"[DataValidation] Rule: {check_type} | col={column} | "
                    f"severity={severity}"
                )

        # No column-level checks → return df unchanged
        if not fail_columns:
            empty = self.spark.createDataFrame([], df.schema)
            return df, empty

        # Build composite failure flag: row fails if ANY check fails
        fail_flag = fail_columns[0]
        for expr in fail_columns[1:]:
            fail_flag = fail_flag | expr

        df = df.withColumn("_dq_failed", fail_flag)
        clean_df     = df.filter(~F.col("_dq_failed")).drop("_dq_failed")
        quarantine_df = df.filter(F.col("_dq_failed")).drop("_dq_failed")

        fail_count = quarantine_df.count()
        pass_count = clean_df.count()
        logger.info(
            f"[DataValidation] {source_name}: "
            f"PASS={pass_count} | FAIL={fail_count}"
        )

        if fail_count > 0 and has_error_severity:
            logger.warning(
                f"[DataValidation] {fail_count} rows failed ERROR-severity "
                f"checks in '{source_name}' — rows quarantined, pipeline continues"
            )

        return clean_df, quarantine_df

    # ── Fail expression builders ──────────────────────────────────────────────

    def _build_fail_expr(self, check: str, column: str,
                         rule: dict, df: DataFrame) -> Optional[F.Column]:
        """
        Returns a Spark Column expression that evaluates to TRUE when
        a row FAILS the given check. Returns None if check cannot be built.
        """
        if column not in df.columns:
            logger.warning(
                f"[DataValidation] Column '{column}' not in DataFrame — "
                f"check '{check}' skipped"
            )
            return None

        if check == "not_null":
            return F.col(column).isNull()

        elif check == "unique":
            # Mark duplicate rows as failures using a window count
            from pyspark.sql.window import Window
            window    = Window.partitionBy(column)
            dup_flag  = F.count("*").over(window) > 1
            return dup_flag

        elif check == "regex":
            pattern = rule.get("regex_pattern", ".*")
            return F.col(column).isNull() | ~F.col(column).rlike(pattern)

        elif check == "min_value":
            min_val = rule.get("min_value")
            if min_val is None:
                return None
            return F.col(column) < min_val

        elif check == "max_value":
            max_val = rule.get("max_value")
            if max_val is None:
                return None
            return F.col(column) > max_val

        return None

    # ── Quarantine writer ─────────────────────────────────────────────────────

    def _save_quarantine(self, df: DataFrame, source_name: str) -> None:
        """Append failed rows to mddi.quarantine with pipeline context columns."""
        try:
            from utils.config_loader import PipelineConfig
            enriched = (
                df
                .withColumn("_source_name",   F.lit(source_name))
                .withColumn("_pipeline_label", F.lit(self.config.label))
                .withColumn("_quarantine_ts",  F.current_timestamp())
            )
            enriched.write.format("delta").mode("append") \
                .option("mergeSchema", "true") \
                .saveAsTable("mddi.quarantine")
            logger.info(
                f"[DataValidation] Quarantine: {df.count()} rows "
                f"from '{source_name}' saved to mddi.quarantine"
            )
        except Exception as e:
            logger.warning(f"[DataValidation] Could not save quarantine rows: {e}")
