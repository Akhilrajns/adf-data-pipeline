# steps/data_extraction.py
# ─────────────────────────────────────────────
# MDDI — DataExtraction Step
#
# Reads every entry in dataExtractionRef.
# Each source is:
#   - Loaded into a Spark DataFrame
#   - Registered as a temp view named after the source (e.g. "COUNTRY", "REGION")
#   - Row count recorded in metrics
#
# Supports:
#   dataSourceType: File   → CSV / Parquet / JSON / DAT (inferred from extension)
#   dataSourceType: Database → JDBC via connection_ref
#   sqlQueryRef.isActive   → overrides table read with a SQL query
#
# Returns: dict of { source_name: DataFrame }
# ─────────────────────────────────────────────

from typing import Dict, List
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType
from monitoring.logger import MDDILogger
from monitoring.metrics import PipelineMetrics
from utils.config_loader import PipelineConfig
from utils.schema_builder import build_spark_schema

logger = MDDILogger.get_logger(__name__)

# File extension → Spark format string
_EXT_FORMAT = {
    "csv":     "csv",
    "json":    "json",
    "parquet": "parquet",
    "dat":     "csv",      # DAT files treated as delimited text
}

# Default read options per format
_READ_OPTIONS = {
    "csv": {
        "header":      "true",
        "inferSchema": "false",   # schema comes from sourceMetadataRef
        "sep":         ",",
        "nullValue":   "",
        "encoding":    "UTF-8",
    },
    "dat": {
        "header":  "false",
        "sep":     "|",
        "nullValue": "",
    },
    "json": {
        "multiLine": "false",
    },
    "parquet": {},
}


class DataExtractionStep:
    """
    Executes the DataExtraction step of the pipeline.

    Iterates over dataExtractionRef entries, reads each source,
    registers it as a Spark temp view, and returns all DataFrames.
    """

    def __init__(self, spark: SparkSession, config: PipelineConfig,
                 metrics: PipelineMetrics):
        self.spark   = spark
        self.config  = config
        self.metrics = metrics

    def execute(self) -> Dict[str, DataFrame]:
        """
        Execute DataExtraction for all sources in dataExtractionRef.

        Returns:
            { source_name: DataFrame }  (e.g. {"COUNTRY": df1, "REGION": df2})
        """
        sources: Dict[str, DataFrame] = {}
        extraction_refs: List[dict] = self.config.data_extraction_ref

        if not extraction_refs:
            raise ValueError(
                "[DataExtraction] dataExtractionRef is empty — "
                "no sources defined in the pipeline YAML."
            )

        for source_ref in extraction_refs:
            source_type = source_ref.get("dataSourceType", "File").lower()
            source_name_raw = source_ref.get("dataSourceName", "")   # e.g. "COUNTRY.csv"
            file_path       = source_ref.get("dataSourceFilePath", "")
            sql_ref         = source_ref.get("sqlQueryRef", {})

            # Derive logical source name (strip extension → "COUNTRY")
            logical_name = source_name_raw.rsplit(".", 1)[0].upper()

            logger.info(
                f"[DataExtraction] Source: {logical_name} | "
                f"type={source_type} | file={source_name_raw}"
            )

            if source_type == "file":
                df = self._read_file(
                    source_name_raw=source_name_raw,
                    base_path=file_path,
                    logical_name=logical_name,
                    sql_ref=sql_ref,
                )
            elif source_type == "database":
                df = self._read_database(source_ref, logical_name, sql_ref)
            else:
                raise ValueError(
                    f"[DataExtraction] Unknown dataSourceType: '{source_type}'. "
                    f"Supported: File, Database."
                )

            # Register as temp view so downstream steps can reference by name
            df.createOrReplaceTempView(logical_name)
            logger.info(
                f"[DataExtraction] Registered temp view: {logical_name}"
            )

            row_count = df.count()
            self.metrics.set_source_count(logical_name, row_count)

            sources[logical_name] = df

        return sources

    # ── File reader ───────────────────────────────────────────────────────────

    def _read_file(self, source_name_raw: str, base_path: str,
                   logical_name: str, sql_ref: dict) -> DataFrame:
        """
        Read a file source. Infers Spark format from file extension.
        Applies schema from sourceMetadataRef if defined.
        Falls back to inferSchema if no schema found.
        """
        ext = source_name_raw.rsplit(".", 1)[-1].lower() if "." in source_name_raw else "csv"
        fmt = _EXT_FORMAT.get(ext, "csv")

        full_path = (
            f"{base_path}/{source_name_raw}" if base_path else source_name_raw
        )

        # Build schema from sourceMetadataRef if available
        schema_def = self.config.get_source_schema(logical_name)
        spark_schema: StructType = None
        if schema_def:
            spark_schema = build_spark_schema(schema_def.get("attributes", []))
            logger.info(
                f"[DataExtraction] Applying schema from sourceMetadataRef "
                f"for {logical_name}: {len(schema_def['attributes'])} columns"
            )

        options = {**_READ_OPTIONS.get(ext, {})}

        reader = self.spark.read.format(fmt).options(**options)
        if spark_schema:
            reader = reader.schema(spark_schema)

        # sqlQueryRef override: read full file then apply SQL filter
        df = reader.load(full_path)

        if sql_ref.get("isActive") and sql_ref.get("query"):
            logger.info(f"[DataExtraction] Applying sqlQueryRef for {logical_name}")
            df.createOrReplaceTempView(f"_raw_{logical_name}")
            df = self.spark.sql(sql_ref["query"])

        return df

    # ── Database reader ───────────────────────────────────────────────────────

    def _read_database(self, source_ref: dict, logical_name: str,
                       sql_ref: dict) -> DataFrame:
        """
        Read from a JDBC database source.
        Requires connection_ref in the source entry pointing to connections.yml.
        """
        conn_ref = source_ref.get("connection_ref", "")
        table    = source_ref.get("table") or logical_name
        query    = sql_ref.get("query") if sql_ref.get("isActive") else None

        if not conn_ref:
            raise ValueError(
                f"[DataExtraction] Database source '{logical_name}' requires "
                "a 'connection_ref' field pointing to a connection in connections.yml."
            )

        # Lazy import to avoid hard dependency when using file sources only
        from connectors.connector_factory import ConnectorFactory
        from utils.connections import load_connections
        conn_config = load_connections().get(conn_ref, {})
        connector = ConnectorFactory.get_connector(
            conn_config.get("type", "mssql"), conn_config, self.spark
        )
        return connector.read(table=table, query=query)
