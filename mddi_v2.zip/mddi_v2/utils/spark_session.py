# utils/spark_session.py
# ─────────────────────────────────────────────
# MDDI — Spark Session Factory
# Returns a configured SparkSession.
# On Databricks clusters, re-uses the existing session.
# Locally, bootstraps a new session with Delta Lake support.
# ─────────────────────────────────────────────

from pyspark.sql import SparkSession


def get_spark(app_name: str = "MDDI_Pipeline") -> SparkSession:
    try:
        # Re-use Databricks cluster session
        from databricks.connect import DatabricksSession
        return DatabricksSession.builder.getOrCreate()
    except ImportError:
        pass

    spark = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    return spark
