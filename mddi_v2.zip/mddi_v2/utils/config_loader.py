# utils/config_loader.py
# ─────────────────────────────────────────────
# MDDI — Config Loader
# Loads a pipeline YAML file and exposes each top-level section
# as a typed property, mirroring the exact YAML structure.
# Resolves ${ENV_VAR} placeholders from the environment.
# ─────────────────────────────────────────────

import os
import re
import yaml
from typing import Any, Dict, List, Optional
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)
_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def _resolve(value: Any) -> Any:
    """Recursively replace ${VAR} placeholders with environment values."""
    if isinstance(value, str):
        return _ENV_PATTERN.sub(
            lambda m: os.environ.get(m.group(1), m.group(0)), value
        )
    if isinstance(value, dict):
        return {k: _resolve(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve(i) for i in value]
    return value


class PipelineConfig:
    """
    Wraps a loaded pipeline YAML and exposes every metadataConfig section
    as a named property with the exact field names from the YAML schema.
    """

    def __init__(self, path: str):
        with open(path, "r") as f:
            raw = yaml.safe_load(f)
        self._meta: Dict = _resolve(raw.get("metadataConfig", raw))
        logger.info(f"[Config] Loaded pipeline: {self.label}")

    # ── Top-level pipeline identity ───────────────────────────────────────────

    @property
    def label(self) -> str:
        return self._meta.get("label", "unnamed_pipeline")

    @property
    def is_active(self) -> bool:
        return self._meta.get("isActive", True)

    @property
    def is_audit_enabled(self) -> bool:
        return self._meta.get("isAuditEnabled", False)

    # ── Schema references ─────────────────────────────────────────────────────

    @property
    def source_metadata_ref(self) -> List[Dict]:
        """
        List of source table schema definitions.
        Each entry: { name, numberOfAttributes, attributes: [{attributeName, attributeType, ...}] }
        """
        return self._meta.get("sourceMetadataRef", [])

    @property
    def target_metadata_ref(self) -> List[Dict]:
        """
        List of target table schema definitions.
        Each entry: { name, numberOfAttributes, attributes: [{attributePosition, attributeName, ...}] }
        """
        return self._meta.get("targetMetadataRef", [])

    # ── Extraction ────────────────────────────────────────────────────────────

    @property
    def data_extraction_ref(self) -> List[Dict]:
        """
        List of source data references.
        Each entry: {
          dataSourceType,      # "File" | "Database"
          dataSourceFilePath,  # base path for file sources
          dataSourceName,      # file name (e.g. COUNTRY.csv) or table name
          sqlQueryRef: { isActive, query }
        }
        """
        return self._meta.get("dataExtractionRef", [])

    # ── Validation ────────────────────────────────────────────────────────────

    @property
    def data_validation_ref(self) -> Dict:
        """
        Validation config block.
        { isActive, rules: [{ sourceName, checkType, column, severity, minRows? }] }
        checkType values: NOT_NULL | UNIQUE | ROW_COUNT | REGEX | MIN_VALUE | MAX_VALUE
        """
        return self._meta.get("dataValidationRef", {})

    # ── Transformation ────────────────────────────────────────────────────────

    @property
    def data_transformation_ref(self) -> Dict:
        """
        Full transformation block.
        {
          dataJoinRef:         { isActive, joins: [{id, joinType, joinObjectName,
                                   sourceName, joinCriteria, filterCriteria, returnAttributes}] }
          dataFilteringRef:    { isActive, filters: [{id, filterName, sourceName, filterCriteria}] }
          calculatedColumnsRef:{ isActive, columns: [{id, columnCategory, columnName,
                                   sourceName, dataType, expression}] }
          lookupRef:           { isActive, lookups: [...] }
          executionSequence:   [ {DataJoin: {join:[1]}}, {DataFiltering: {filter:[1]}}, ... ]
        }
        """
        return self._meta.get("dataTransformationRef", {})

    # ── Load ──────────────────────────────────────────────────────────────────

    @property
    def data_load_ref(self) -> List[Dict]:
        """
        List of load targets.
        Each entry: {
          dataLoadTableName,   # target table/file name
          dataLoadType,        # "File" | "Delta" | "Database"
          dataLoadFileType,    # "csv" | "parquet" | "json" | "dat"
          dataLoadFolder,      # output folder path
          dataMappingTableName,# references dataMappingRef
          dataSourceName       # source view name to load from
        }
        """
        return self._meta.get("dataLoadRef", [])

    # ── Mapping ───────────────────────────────────────────────────────────────

    @property
    def data_mapping_ref(self) -> List[Dict]:
        """
        Column-level source→target mappings.
        [{ targetTableName, attributes: [{sourceAttributeName, targetAttributeName}] }]
        """
        return self._meta.get("dataMappingRef", [])

    # ── Execution sequence ────────────────────────────────────────────────────

    @property
    def data_flow_execution_sequence(self) -> List[str]:
        """
        Ordered list of steps to execute.
        Values: DataExtraction | DataValidation | DataTransformation | DataLoad
        Pipeline executes ONLY the steps listed here, in the given order.
        """
        return self._meta.get("dataFlowExecutionSequence", [])

    # ── Helpers ───────────────────────────────────────────────────────────────

    def get_source_schema(self, source_name: str) -> Optional[Dict]:
        """Return sourceMetadataRef entry for the given source name."""
        for s in self.source_metadata_ref:
            if s.get("name") == source_name:
                return s
        return None

    def get_target_schema(self, target_name: str) -> Optional[Dict]:
        """Return targetMetadataRef entry for the given target name."""
        for t in self.target_metadata_ref:
            if t.get("name") == target_name:
                return t
        return None

    def get_mapping(self, target_table_name: str) -> List[Dict]:
        """Return attribute mappings for the given target table."""
        for m in self.data_mapping_ref:
            if m.get("targetTableName") == target_table_name:
                return m.get("attributes", [])
        return []
