# utils/run_id.py
import uuid
from datetime import datetime


def generate_run_id(label: str) -> str:
    ts  = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    uid = str(uuid.uuid4())[:8]
    safe_label = label.replace(" ", "_").replace("-", "_")
    return f"{safe_label}_{ts}_{uid}"
