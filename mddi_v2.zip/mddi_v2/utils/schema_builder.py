# utils/schema_builder.py
# ─────────────────────────────────────────────
# MDDI — Spark Schema Builder
# Converts sourceMetadataRef / targetMetadataRef attribute definitions
# into PySpark StructType schemas for typed reads.
# ─────────────────────────────────────────────

from typing import List, Dict
from pyspark.sql.types import (
    StructType, StructField,
    StringType, IntegerType, LongType,
    DecimalType, DoubleType, FloatType,
    DateType, TimestampType, BooleanType,
)
from monitoring.logger import MDDILogger

logger = MDDILogger.get_logger(__name__)

# Maps YAML attributeType → PySpark type
_TYPE_MAP = {
    "string":    StringType(),
    "varchar":   StringType(),
    "char":      StringType(),
    "integer":   IntegerType(),
    "int":       IntegerType(),
    "long":      LongType(),
    "bigint":    LongType(),
    "double":    DoubleType(),
    "float":     FloatType(),
    "boolean":   BooleanType(),
    "date":      DateType(),
    "timestamp": TimestampType(),
    "datetime":  TimestampType(),
}


def build_spark_schema(attributes: List[Dict]) -> StructType:
    """
    Convert a list of YAML attribute definitions into a PySpark StructType.

    Each attribute dict: {
      attributeName: str,
      attributeType: str,       # see _TYPE_MAP + "decimal"
      attributeLength: int,     # optional
      precision: int,           # optional — used for decimal
    }
    """
    fields = []
    for attr in attributes:
        name      = attr["attributeName"]
        type_str  = attr.get("attributeType", "string").lower()
        precision = attr.get("precision", 10)
        scale     = attr.get("scale", 2)

        if type_str == "decimal":
            spark_type = DecimalType(precision=precision, scale=scale)
        else:
            spark_type = _TYPE_MAP.get(type_str, StringType())

        fields.append(StructField(name, spark_type, nullable=True))
        logger.debug(f"[Schema] {name}: {type_str} → {spark_type}")

    return StructType(fields)
