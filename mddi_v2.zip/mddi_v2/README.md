# MDDI Framework — Code Generation from YAML

Generated from the reference pipeline YAML:
  `Extract + Validate + Transform + Load.yml`

---

## How It Works

The pipeline is fully driven by the `dataFlowExecutionSequence` in your YAML.
Only the steps listed are executed — in exactly the order defined.

```
dataFlowExecutionSequence:
  - DataExtraction       →  reads COUNTRY.csv + REGION.csv
  - DataValidation       →  NOT_NULL, UNIQUE, ROW_COUNT checks
  - DataTransformation   →  JOIN → FILTER → CALCULATED COLUMN
  - DataLoad             →  writes FULL_PIPELINE_OUTPUT.csv
```

A minimal pipeline needs only:
```yaml
dataFlowExecutionSequence:
  - DataExtraction
  - DataLoad
```

---

## Folder Structure

```
mddi_v2/
│
├── pipeline_runner.py              # Main entry point — reads YAML + drives execution
│
├── steps/
│   ├── data_extraction.py         # DataExtraction step
│   │                              #   reads dataExtractionRef
│   │                              #   applies sourceMetadataRef schema
│   │                              #   registers each source as a Spark temp view
│   │
│   ├── data_validation.py         # DataValidation step
│   │                              #   reads dataValidationRef.rules
│   │                              #   checkTypes: NOT_NULL, UNIQUE, ROW_COUNT,
│   │                              #              REGEX, MIN_VALUE, MAX_VALUE
│   │                              #   severity: ERROR | WARN
│   │                              #   saves failed rows to mddi.quarantine
│   │
│   ├── data_transformation.py     # DataTransformation step
│   │                              #   reads dataTransformationRef.executionSequence
│   │                              #   sub-steps: DataJoin, DataFiltering,
│   │                              #             CalculatedColumns, Lookup
│   │                              #   each sub-step registers a new temp view
│   │
│   └── data_load.py               # DataLoad step
│                                  #   reads dataLoadRef
│                                  #   applies dataMappingRef column renames
│                                  #   projects to targetMetadataRef column order
│                                  #   writes File / Delta / Database
│
├── validators/
│   └── yaml_validator.py          # JSON Schema validator for pipeline YAML
│                                  #   validates all field names + allowed values
│                                  #   run before execution starts
│
├── utils/
│   ├── config_loader.py           # PipelineConfig — typed properties per YAML section
│   ├── schema_builder.py          # sourceMetadataRef → PySpark StructType
│   ├── spark_session.py           # SparkSession factory (Databricks + local)
│   └── run_id.py                  # Unique run ID generator
│
├── monitoring/
│   ├── logger.py                  # Structured JSON logger + Delta persistence
│   └── metrics.py                 # Row counts, DQ stats, duration per run
│
├── config/
│   └── pipelines/
│       └── extract_validate_transform_load.yml  # Your reference pipeline
│
└── tests/unit/
    ├── test_data_extraction.py
    ├── test_data_validation.py
    ├── test_data_transformation.py
    └── test_yaml_validator.py
```

---

## Running a Pipeline

```bash
# Validate the YAML first
python -m validators.yaml_validator \
  --file config/pipelines/extract_validate_transform_load.yml

# Run the full pipeline
python pipeline_runner.py \
  --config config/pipelines/extract_validate_transform_load.yml

# Run tests
pytest
```

---

## YAML Section → Code Mapping

| YAML Section                         | Handled By                          |
|--------------------------------------|-------------------------------------|
| `dataFlowExecutionSequence`          | `pipeline_runner.py`                |
| `dataExtractionRef`                  | `steps/data_extraction.py`          |
| `sourceMetadataRef`                  | `utils/schema_builder.py`           |
| `dataValidationRef.rules`            | `steps/data_validation.py`          |
| `dataTransformationRef.dataJoinRef`  | `DataTransformationStep._handle_data_join` |
| `dataTransformationRef.dataFilteringRef` | `DataTransformationStep._handle_data_filtering` |
| `dataTransformationRef.calculatedColumnsRef` | `DataTransformationStep._handle_calculated_columns` |
| `dataTransformationRef.executionSequence` | `DataTransformationStep.execute` |
| `dataLoadRef`                        | `steps/data_load.py`                |
| `dataMappingRef`                     | `steps/data_load.py._apply_mapping` |
| `targetMetadataRef`                  | `steps/data_load.py._project_to_target_schema` |

---

## Execution Flow for the Reference YAML

```
pipeline_runner.py
│
├── [1] DataExtraction
│       reads COUNTRY.csv  → temp view: COUNTRY
│       reads REGION.csv   → temp view: REGION
│
├── [2] DataValidation
│       COUNTRY.COUNTRYID  NOT_NULL   (ERROR)
│       COUNTRY.COUNTRYNAME NOT_NULL  (ERROR)
│       COUNTRY.COUNTRYID  UNIQUE     (ERROR)
│       COUNTRY            ROW_COUNT ≥ 1 (ERROR)
│       REGION.REGIONID    NOT_NULL   (ERROR)
│       REGION             ROW_COUNT ≥ 1 (ERROR)
│       ↳ failed rows → mddi.quarantine
│
├── [3] DataTransformation
│       DataJoin          COUNTRY ⟕ REGION ON REGIONID
│                         → temp view: JOIN_RESULT
│       DataFiltering     WHERE HEMISPHERE = 'Northern'
│                         → temp view: NORTHERN
│       CalculatedColumns COUNTRY_INFO = CONCAT(COUNTRYNAME, ' - ', CONTINENT)
│
└── [4] DataLoad
        reads temp view: NORTHERN
        applies dataMappingRef renames
        projects to targetMetadataRef columns:
          COUNTRYNAME, CONTINENT, HEMISPHERE, COUNTRY_INFO
        writes → FULL_PIPELINE_OUTPUT.csv
```
